#ifndef	CIDERTREE_CPP
#define	CIDERTREE_CPP

#include "BitSequence.h"
#include "MutableList.h"
#include "ArrayList.h"
#include "SinglyLinkedList.h"
#include "Log.h"
#include <limits.h>

namespace Juice{

	class CiderTree{
	private:

		//STATIC PORTION

		class Branch{
			public:
				Branch * branch0;
				Branch * branch1;
				ArrayList<unsigned long long int> index;				//Doesn't have to be singly.  Can be any MutableList.
				unsigned long long int keyDepth;

				Branch *& operator[](bool select){
					return select ? branch1 : branch0;
				}
		};

	public:
		
		/*Source is the raw data.  Indicies is actually a return value.*/
		static long long int GetBestKey(BitSequence& source, BitSequence& outputKey, ArrayList<unsigned long long int>& outputIndicies, unsigned long long int macroLimit = ULLONG_MAX){
			Branch * root = new Branch();
			root->index.Length(source.Length());
			root->keyDepth = 0;
			for(unsigned long long int i = 0ULL; i < source.Length(); ++i)
				root->index[i] = i;
			
			SinglyLinkedList<Branch*> unprocessed;
			unprocessed += root;

			long long int greatestProfit = LLONG_MIN;			//Establishes the most profitable term.
			Branch * bestBranch = new Branch();					//Can't be root because it'll be deleted on the first pass at the end.
			while(unprocessed.Length()){
				Branch& current = *(--unprocessed);

				current.branch0 = new Branch();					//Create two new buds.
				current.branch1 = new Branch();
																//Create the two new key depths for each respective branch.
				current.branch0->keyDepth = current.branch1->keyDepth = current.keyDepth + 1;

																//OPVAR's and indexes of each branch.
				ArrayList<unsigned long long int>& index0 = current.branch0->index;
				ArrayList<unsigned long long int>& index1 = current.branch1->index;
																//Initializes the indexes of each branch, setting it to the maximum possible size.
				index0.Length(current.index.Length());
				index1.Length(current.index.Length());

				unsigned long long int i0 = 0ULL;				//counter for index0 (records the size of the index0 array)
				unsigned long long int i1 = 0ULL;				//counter for index1 (records the size of the index1 array)

				unsigned long long int lastIndex = current.index.Length()-1;		//opvar
				unsigned long long int keyDepth = current.keyDepth+1;
				
				for(unsigned long long int j = 0ULL; j < lastIndex; ++j){			//Splits all of the index locations from the current branch and feeds it into the repspective buds.
					if(source.Read(current.index[j]+keyDepth)){
						if(i1==0 || (index1[i1-1] + keyDepth < current.index[j]))
							index1[i1++] = current.index[j];
					}else{
						if(i0==0 || (index0[i0-1] + keyDepth < current.index[j]))
							index0[i0++] = current.index[j];
					}
					//while(j<lastIndex && current.index[j] + keyDepth > current.index[j+1])			//This clause prevents terms from overlapping each other (oompaloompaloompaloompa).
						//++j;														//Technically I think you save more space by preserving as many end-terms as possible (smaller pointers)
				}
				
				if((current.index[lastIndex]+keyDepth < source.Length()) && //This condition only needs to be run on the last item in the list, to make sure it doesn't extend past the end.	
					(current.index.Length() == 1 || current.index[lastIndex] > current.index[lastIndex-1] + keyDepth)){	//Prevents the last term from overlapping the one that came before it.
					if(source.Read(current.index[lastIndex]+keyDepth))
						index1[i1++] = current.index[lastIndex];
					else
						index0[i0++] = current.index[lastIndex];
				}
															//Shrink the two indicies from the maximum to their actual size.
				
				/*If the term is non-unique, move the branches to be processed.  Otherwise, delete them.*/
				if(i0>1){
					unprocessed += current.branch0;
					index0.Length(i0);	//Shrink only after you know you might be keeping.
				}else
					delete current.branch0;

				if(i1>1){
					index1.Length(i1);	//Shrink only after you know you might be keeping.
					unprocessed += current.branch1;
				}else
					delete current.branch1;

				long long int profit = getProfit(source, current.index, current.keyDepth, macroLimit);
				if(profit > greatestProfit){
					greatestProfit = profit;
					delete bestBranch;
					bestBranch = &current;
				}else	//If not more profitable than the most profitable branch, delete this one.
					delete &current;
			}

			outputIndicies = bestBranch->index;
			outputKey = source.Read(bestBranch->index[0], bestBranch->keyDepth);
			delete bestBranch;
			return greatestProfit;
		}

	private:

		static long long int getProfit(BitSequence& source, ArrayList<unsigned long long int>& index, unsigned long long int keyLength, unsigned long long int macroLimit = ULLONG_MAX){	//Returns the profit for a particular term.
			unsigned long long int dataLength = source.Length() - keyLength * index.Length();
			long long int profit = 
				keyLength * index.Length()			//Total Area removed (in keys)
				- Integer::BinaryLog(dataLength)*2			//First Pointer + length of data (are the same)
				- keyLength							//Key
				- Integer::BinaryLog(keyLength)				//Size of key
				- Integer::BinaryLog(Integer::BinaryLog(dataLength)-1)//Size of size of key
				- Integer::BinaryLog(Integer::BinaryLog(macroLimit))	//Size of size of Data
				- 6;								//Size of size of NumAtEnd
			
			unsigned long long int numAtEnd = 0ULL;
			unsigned long long int currentPointer = source.Length() - keyLength;
			unsigned long long int currentIndex = index.Length() - 1;
			while(currentPointer == index[currentIndex]){
				currentPointer -= keyLength;
				currentIndex--;
				numAtEnd++;
			}	//Gets numAtEnd;
			profit -= Integer::BinaryLog(numAtEnd);	//NumAtEnd
			
			for(unsigned long long int i = 0ULL; i < index.Length() - numAtEnd; ++i)	//Size of pointers.
				profit -= Integer::BinaryLog(dataLength - (index[i] - i * keyLength));
			
			return profit;
		}
	};
}

#endif
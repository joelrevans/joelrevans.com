#ifndef PROBABLYCIDER_H
#define PROBABLYCIDER_H

namespace Juice{
	class ProbablyCider{
	public:
		void Press(BitSequence& source, unsigned char elementSize){
			unsigned long long int numEl = (1<<elementSize); //2^elementSize
			ArrayList<unsigned long long int> elements(numEl);
			
			unsigned long long int currentPos = 0ULL;
			while(currentPos+elementSize < source.Length()){
				elements[source.Read(currentPos, elementSize).ToObject<unsigned long long int>()]++;
				currentPos += elementSize;
			}
			BitSequence last = source.Read(currentPos, source.Length() - currentPos);
			
			
			
		}

		void Depress(BitSequence& source, unsigned char elementSize){

		}
	};
}

#endif
#ifndef LOG_H
#define LOG_H

namespace Juice{

	/*Tested moderately well, but not thoroughly.*/
	/*Returns the integer value of the logarithm, base 2, of a number.*/

/*	static unsigned char Integer::BinaryLog(unsigned long long int number){
		unsigned char answer = 0;
		if(number & 0xFFFFFFFF00000000ULL){
			answer|=32;
			number>>=32;
		}
		if(number & 0xFFFF0000ULL){
			answer|=16;
			number>>=16;
		}
		if(number & 0xFF00ULL){
			answer|=8;
			number>>=8;
		}
		if(number & 0xF0ULL){
			answer|=4;
			number>>=4;
		}
		if(number & 0xCULL){
			answer|=2;
			number>>=2;
		}
		if(number & 0x2ULL){
			answer|=1;
			number>>=1;
		}
		if(number)
			++answer;	//Dere aint no way to represent 64 in 5 bits, so you gots the plus.
		return answer;
	}

	/*static unsigned char Integer::BinaryLog(unsigned long long int number){
		unsigned long long int answer = 0;
		while(number){
			answer++;
			number>>=1;
		}
		return answer;	//you start at 0x1, not 0x0, so you shift one at the end;
	}*/
}
#endif
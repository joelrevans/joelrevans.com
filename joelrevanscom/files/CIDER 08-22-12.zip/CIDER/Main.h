using namespace std;

#include <iostream>

#include "BitPatternTree.h"
#include <fstream>
#include "testmethods.h"
#include "SpikedCider.h"

#include <direct.h>

using namespace Juice;

int main(){

	//char currentPath[1000];

	//cout << _getcwd(currentPath, sizeof(currentPath) / sizeof(char)) << endl;
	
	fstream fs;
	
	/*Test if it opens.*/
	fs.open("enwik");
	cout << "is_open:  " << fs.is_open() << endl;
	
	fs.seekg(0, ios::end);
	unsigned long long int byteLength = fs.tellg();

	char * enwik = new char[byteLength];
	fs.seekg(0, ios::beg);
	fs.read(enwik, byteLength);
	fs.close();
	
	cout << "Data copied.  Creating Sequence..." << endl;

	BitSequence enwikBin = BitSequence(enwik, byteLength*8);

	delete [] enwik;

	cout << "Pre-compression Length:  " << enwikBin.Length() << endl;
	BitSequence enwikCompare = enwikBin;	//Save the data for verification.
	
	SpikedCider::MacroPress(enwikBin, 11);	
	cout << "Post-compression length:  " << enwikBin.Length() << endl;

	SpikedCider::MacroDepress(enwikBin);

	cout << "Verifying data integrity..." << endl;
	cout << (enwikCompare==enwikBin?"Data Integrity Verified":"Failure")<<endl;

	system("pause");
    return 0;
}/**/

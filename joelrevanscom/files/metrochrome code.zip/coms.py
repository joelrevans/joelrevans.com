import ast			#Used by InitBatch to parse DyeInfo into a dictionary
import Pyro.core	#Runs the server
import json
import thread

MetroService = Pyro.core.getProxyForURI("PYROLOC://localhost:7766/MetroService") #match the URL specified in the daemon.

def ping(val):	
	return MetroService.Ping(val)
	
def GetTemp(ChamberID):
	return str(MetroService.GetTemp(int(ChamberID)))
	
def AbortBatch(ChamberID):
	MetroService.AbortBatch(int(ChamberID))
	return "Abort Command Sent"
	
def GetChamberState(ChamberID):
	return MetroService.GetChamberState(int(ChamberID))
	
def FlushInjectors(Duration):
	MetroService.FlushInjectors(float(Duration))
	return "Flushing Injectors..."

def TestInjector(InjectorID, Duration):
	MetroService.TestInjector(int(InjectorID), float(Duration))
	return "Testing Injector"
	
def Rinse(ChamberID, Duration):
	MetroService.Rinse(int(ChamberID), float(Duration))
	return "Rinsing..."
	
def IsHeaterOn(ChamberID):
	return MetroService.IsHeaterOn(int(ChamberID))
	
def IsDrainOpen(ChamberID):
	return MetroService.IsDrainOpen(int(ChamberID))
	
def IsInjectorOn(InjectorID):
	return MetroService.IsInjectorOn(int(InjectorID))
	
def DumpSensors():
	str = MetroService.DumpSensors()
	print(str)
	return str
	
#0, "{'RED':10, 'YELLOW':20, 'WATER':30}", 50, 30, 35, 30
#metrochrome.com/coms.py/InitBatch?ChamberID=0&DyeInfo={'RED':10,'YELLOW':20,'WATER':30}&TargetTemp=50&CureTime=30&CoolTemp=35&DryTime=30

def InitBatch(ChamberID, DyeInfo, TargetTemp, CureTime, CoolTemp, DryTime):
	try:
		DyeInfo = ast.literal_eval(DyeInfo)	#Try and parse the Dye Info as a dictionary
	except:
		return "Unable to parse DyeInfo parameter as dictionary"

	ChamberID = int(ChamberID)
	TargetTemp = float(TargetTemp)
	CureTime = float(CureTime)
	CoolTemp = float(CoolTemp)
	DryTime = float(DryTime)
		
	for dye in DyeInfo:	#make sure DyeInfo quantities are expressed as integers or floats
		DyeInfo[dye] = float(DyeInfo[dye])
	
	thread.start_new_thread(InitBatchThread, (ChamberID, DyeInfo, TargetTemp, CureTime, CoolTemp, DryTime))
	return "Initializing Batch Cycle..."
	
def InitBatchThread(ChamberID, DyeInfo, TargetTemp, CureTime, CoolTemp, DryTime):
	MetroService.InitBatch(ChamberID, DyeInfo, TargetTemp, CureTime, CoolTemp, DryTime)
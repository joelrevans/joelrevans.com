import Pyro.core
import RPi.GPIO as GPIO
import time,sys,json,os,glob
#import thread
import threading
import ast

class Chamber:

	MEMBERS = []
	Agitating = False

	class OPERATING_STATE:
		IDLE = 0
		INJECTING = 1
		HEATING = 2
		HOLDING = 3
		COOLING = 4
		DRAINING = 5
		DRYING = 6

	def __init__(self, drain, heater, temp_dir):
		self.drain = drain
		self.heater = heater
		self.temp_dir = "/sys/bus/w1/devices/28-0000058d" + temp_dir + "/w1_slave";
		self.state = Chamber.OPERATING_STATE.IDLE
		self.HeaterState = False
		self.DrainState = False
		
		GPIO.setup(self.heater, GPIO.OUT)
		GPIO.setup(self.drain, GPIO.OUT)
		
		self.HeaterOff()
		self.DrainClose()
		self.Abort = False
		
		Chamber.MEMBERS.append(self)
	
	def __del__(self):
		self.AbortBatch()
	
	def AbortBatch(self):
		self.Abort = True
	
	def GetTemp(self):
		while True:
			f = open(self.temp_dir, 'r')
			
			lines = f.readlines()
			f.close()
			if lines[0].strip()[-3:] == 'YES':
				break
			else:
				time.sleep(0.2)			
				
		equals_pos = lines[1].find('t=')
		if equals_pos != -1:
			temp_string = lines[1][equals_pos+2:]
			temp_c = float(temp_string) / 1000.0
			return temp_c
		return 0
	
	def IsHeaterOn(self):
		return self.HeaterState
	
	def HeaterOn(self):
		GPIO.output(self.heater, RELAY_ON)
		self.HeaterState = True
	
	def HeaterOff(self):
		GPIO.output(self.heater, RELAY_OFF)
		self.HeaterState = False
		
	def IsDrainOpen(self):
		return self.DrainState
		
	def DrainOpen(self):
		GPIO.output(self.drain, RELAY_ON)
		self.DrainState = True
	
	def DrainClose(self):
		GPIO.output(self.drain, RELAY_OFF)
		self.DrainState = False

	def GetState(self):
		return self.state;
		
	def InjectingPhase(self, DyeInfo, TargetTemp, CureTime, CoolTemp, DryTime):
		self.state = Chamber.OPERATING_STATE.INJECTING
		self.DyeInfo = DyeInfo
		self.TargetTemp = TargetTemp
		self.CureTime = CureTime
		self.CoolTemp = CoolTemp
		self.DryTime = DryTime
		
	def HeatingPhase(self):
		self.state = Chamber.OPERATING_STATE.HEATING
		self.HeaterOn()
		while self.GetTemp() < self.TargetTemp:
			if self.Abort:
				self.IdlePhase()
				return
			time.sleep(5)
		self.HoldingPhase()
		
	def HoldingPhase(self):
		self.state = Chamber.OPERATING_STATE.HOLDING
		timer = threading.Timer(self.CureTime, self.CoolingPhase)	#Start a timer to advance us to the next phase
		timer.start()
		while self.state == Chamber.OPERATING_STATE.HOLDING:
			if self.Abort:
				timer.cancel()
				self.IdlePhase()
				return
			currentTemp = self.GetTemp()
			if currentTemp > self.TargetTemp:
				GPIO.output(self.heater, RELAY_OFF)
			else:
				GPIO.output(self.heater, RELAY_ON)
			time.sleep(5)
		GPIO.output(self.heater, RELAY_OFF)
		
	def CoolingPhase(self):
		self.state = Chamber.OPERATING_STATE.COOLING
		while self.GetTemp() > self.CoolTemp:
			time.sleep(5)
			if self.Abort:
				self.IdlePhase()
				return
		self.DrainingPhase()
		
	def DrainingPhase(self):
		self.state = Chamber.OPERATING_STATE.DRAINING
		self.DrainOpen()
		for i in range(12):
			time.sleep(5)
			if self.Abort:
				self.IdlePhase()
				return
		self.DryingPhase()
		
	def DryingPhase(self):
		self.state = Chamber.OPERATING_STATE.DRYING
		if self.DryTime > 0:
			self.HeaterOn()
		
		timer = threading.Timer(self.DryTime, self.IdlePhase)
		timer.start()
		while self.state == Chamber.OPERATING_STATE.DRYING:
			if self.Abort:
				self.IdlePhase()
				return
			currentTemp = self.GetTemp()
			if currentTemp >= self.TargetTemp:
				GPIO.output(self.heater, RELAY_OFF)
			else:
				GPIO.output(self.heater, RELAY_ON)
		GPIO.output(self.heater, RELAY_OFF)
		
	def IdlePhase(self):
		self.state = Chamber.OPERATING_STATE.IDLE
		self.HeaterOff()
		self.DrainClose()
		self.DyeInfo = 0
		self.TargetTemp = 0
		self.CureTime = 0
		self.CoolTemp = 0
		self.DryTime = 0
		self.Abort = False
		
		#If all chambers are idle, shut down the agitator
		chambersAreIdle = True
		for chamber in Chamber.MEMBERS:
			if chamber.state != Chamber.OPERATING_STATE.IDLE:
				chambersAreIdle = False
		if chambersAreIdle:
			Chamber.HaltAgitation()
		
	#Because the agitation valve is shared, a static process exists to manage the resources for all chambers
	@staticmethod
	def HaltAgitation():
		Chamber.Agitating = False
		GPIO.output(AGITATOR, RELAY_OFF)
	
	@staticmethod
	def ResumeAgitation():
		Chamber.Agitating = False
		time.sleep(2)	#terminate the other agitation threads
		Chamber.Agitating = True
		ags = threading.Thread(target=Chamber.Agitate)
		ags.start()
		
	@staticmethod
	def Agitate():
		while True:
			GPIO.output(AGITATOR, RELAY_ON)
			time.sleep(3)
			GPIO.output(AGITATOR, RELAY_OFF)
			for i in range(87):
				time.sleep(1)
				if Chamber.Agitating == False:
					return
		

class MetroService(Pyro.core.ObjBase):
	def __init__(self):
		Pyro.core.ObjBase.__init__(self)

		Chamber(8, 7,"6b52")
		Chamber(24,25,"b954")
		Chamber(18, 23,"b6b7")
		Chamber(14, 15,"82b4")
		
	#used to test the daemon.
	def Ping(self, pong):
		return pong
	
	def TestInjector(self, InjectorID, Duration):
		GPIO.output(INJECTORS[InjectorID], RELAY_ON)
		time.sleep(Duration)
		GPIO.output(INJECTORS[InjectorID], RELAY_OFF)
	
	def FlushInjectors(self, Duration):
		for Injector in INJECTORS:
			GPIO.output(Injector, RELAY_ON)
		time.sleep(Duration)
		for Injector in INJECTORS:
			GPIO.output(Injector, RELAY_OFF)
	
	def GetTemp(self, ChamberID):
		return Chamber.MEMBERS[ChamberID].GetTemp()
	
	def GetChamberState(self, ChamberID):
		return Chamber.MEMBERS[ChamberID].state
	
	def IsHeaterOn(self, ChamberID):
		return Chamber.MEMBERS[ChamberID].HeaterState
		
	def IsDrainOpen(self, ChamberID):
		return Chamber.MEMBERS[ChamberID].DrainState
	
	def AbortBatch(self, ChamberID):
		Chamber.MEMBERS[ChamberID].AbortBatch()
		for Injector in INJECTORS:
			GPIO.output(Injector, RELAY_OFF)
	
	def Rinse(self, ChamberID, Duration):
		Chamber.MEMBERS[ChamberID].DrainOpen()
		#GPIO.output(DYE_INJECTORS["WATER"], RELAY_ON)
		for i in range(0, int(Duration)):
			time.sleep(1)
			if Chamber.MEMBERS[ChamberID].Abort == True:
				break
		Chamber.MEMBERS[ChamberID].DrainClose()
		#GPIO.output(DYE_INJECTORS["WATER"], RELAY_OFF)
	
	def IsInjectorOn(self, Color):
		return INJECTOR_STATUS[Color];
	
	def InitBatch(self, ChamberID, DyeInfo, TargetTemp, CureTime, CoolTemp, DryTime):
		for chamber in Chamber.MEMBERS:		#make sure the injectors are not currently in use
			if chamber.state == Chamber.OPERATING_STATE.INJECTING:
				return "The injectors are currently in use by another chamber."

		Chamber.MEMBERS[ChamberID].InjectingPhase(DyeInfo, TargetTemp, CureTime, CoolTemp, DryTime)
		
		Chamber.HaltAgitation()					#Stops agitation so we don't lose pressure in the injector lines
			
		for color in DyeInfo:						#first check to make sure all colors exist
			if color not in DYE_INJECTORS:
				print("Dye does not exist for the specified color: " + color[0])
		
		for color in DyeInfo:						#If all colors exist, then you may begin injection
			fullsecs = int(DyeInfo[color] / DYE_FLOWRATE)
			partsecs = DyeInfo[color] / DYE_FLOWRATE - fullsecs
			GPIO.output(DYE_INJECTORS[color], RELAY_ON)
			INJECTOR_STATUS[DYE_INJECTORS[color]] = True
			for i in range(fullsecs):
				time.sleep(1)
				if Chamber.MEMBERS[ChamberID].Abort == True:
					break
			time.sleep(partsecs)
			GPIO.output(DYE_INJECTORS[color], RELAY_OFF)
			INJECTOR_STATUS[DYE_INJECTORS[color]] = False
			
		Chamber.ResumeAgitation()
		Chamber.MEMBERS[ChamberID].HeatingPhase()
		
	def DumpSensors(self):
		return json.dumps({ \
		"temp0" : self.GetTemp(0), "temp1" : self.GetTemp(1), "temp2" : self.GetTemp(2), "temp3" : self.GetTemp(3), \
		"status0" : self.GetChamberState(0),"status1" : self.GetChamberState(1),"status2" : self.GetChamberState(2),"status3" : self.GetChamberState(3), \
		"heater0" : self.IsHeaterOn(0), "heater1" : self.IsHeaterOn(1), "heater2" : self.IsHeaterOn(2), "heater3" : self.IsHeaterOn(3), \
		"drain0" : self.IsDrainOpen(0),"drain1" : self.IsDrainOpen(1),"drain2" : self.IsDrainOpen(2),"drain3" : self.IsDrainOpen(3), \
		"Injector0" : INJECTOR_STATUS[INJECTORS[0]],"Injector1" : INJECTOR_STATUS[INJECTORS[1]],"Injector2" : INJECTOR_STATUS[INJECTORS[2]], \
		"Injector3" : INJECTOR_STATUS[INJECTORS[3]],"Injector4" : INJECTOR_STATUS[INJECTORS[4]],"Injector5" : INJECTOR_STATUS[INJECTORS[5]] \
		})
	
#Initialize the thermal sensors
os.system('modprobe w1-gpio')
os.system('modprobe w1-therm')

#Set GPIO pins
GPIO.setmode(GPIO.BCM) #sets the convention for accessing IO pins.
RELAY_ON = False
RELAY_OFF = True

#Set Injectors
DYE_FLOWRATE = 0.5	#1mL every two seconds
INJECTORS = [9, 10, 11, 17, 22, 27]
INJECTOR_STATUS = {INJECTORS[0] : False, INJECTORS[1] : False, INJECTORS[2] : False, INJECTORS[3] : False, INJECTORS[4] : False, INJECTORS[5] : False}
for injector in INJECTORS:
	GPIO.setup(injector, GPIO.OUT)
	GPIO.output(injector, RELAY_OFF)

#Set Dyes
DYE_INJECTORS = {"ADDITIVES":INJECTORS[0], "BROWN" : INJECTORS[1], "BLUE" : INJECTORS[2], "WATER" : INJECTORS[3], "RED" : INJECTORS[4], "YELLOW" : INJECTORS[5]}

#Set Agitator
AGITATOR = 2
GPIO.setup(AGITATOR, GPIO.OUT)
GPIO.output(AGITATOR, RELAY_OFF)
	
#initialize the daemon, socket server, and web service.
Pyro.core.initServer()
daemon=Pyro.core.Daemon()
uri=daemon.connect(MetroService(),"MetroService")

print "The daemon runs on port:",daemon.port
print "The object's uri is:",uri


daemon.requestLoop()

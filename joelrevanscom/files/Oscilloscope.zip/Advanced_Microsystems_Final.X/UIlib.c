int PORTB_STATE;
float SCOPE_Width;
float SCOPE_Height;
float SCOPE_DCOffset;

unsigned char SCOPE_TracerState;
//0=playing
//1=paused

int SCOPE_TracerPosition = 512;

unsigned char SCOPE_TriggerDirection;
//0=rolling
//1=up
//2=down

float SCOPE_TriggerValue;

unsigned char MENU_STATE;
//0=Width
//1=Height
//2=Vert
//3=Trigger
//4=Trace

void UI_InitButtons()
{
	//Hardware buttons
	TRISB |= 0x1F00;    //bits 8-12 are inputs
	AD1PCFGL |= 0x1F00; //bits 8-12 are digital
	CNEN2 |= 0x7C00;    //Enable interrupt for _RB8-12
	IEC1bits.CNIE = 1;  //Enable input change interrupt.
	
	PORTB_STATE = PORTB;
	
	//Software Buttons
	LCD_WriteInvertedBitmap(1,56,7,7,LCD_sW);
	LCD_WriteBitmap(8,56,6,7,LCD_sH);
	LCD_WriteBitmap(14,56,7,7,LCD_sV);
	LCD_WriteBitmap(21,56,7,7,LCD_sSIN);
	LCD_WriteBitmap(28,56,7,7,LCD_sPLAY);
	
	char * print = floatToBCD(SCOPE_Width, 'S');
	LCD_WriteChars(40, 57, print);
	free(print);
	LCD_WriteBitmap(62, 0, 3, 2, LCD_sTracerVert);
}

float IO_MostSignificantDigitValue(float input)
{
	if(input >=10)
		return 10;
	else if(input >= 1)
		return 1;
	else if(input >= 0.1)
		return 0.1;
	else if(input > 0.01)
		return 0.01;
	else
		return 0.001;
}

void __attribute__ ((interrupt, auto_psv)) _CNInterrupt (void)
{
	if(!_RB12 && (PORTB_STATE & 0x1000))	//UP
	{
		switch(MENU_STATE)
		{
			case 0:
				if(SCOPE_Width < 5)
				{
					SCOPE_Width += IO_MostSignificantDigitValue(SCOPE_Width);
					ADC_SetSamplesPerSecond(1024/SCOPE_Width);
					LCD_ClearPixels(40, 57, 87, 7);
					char * print = floatToBCD(SCOPE_Width, 'S');
					LCD_WriteChars(40, 57, print);
					free(print);
				}
			break;
			case 1:
				if(SCOPE_Height < 20.0)
				{
					SCOPE_Height++;
					LCD_ClearPixels(40, 57, 87, 7);
					char * print = floatToBCD(SCOPE_Height, 'V');
					LCD_WriteChars(40, 57, print);
					free(print);
				}
			break;
			case 2:
			{
				unsigned char duration = 0;
				while(SCOPE_DCOffset < 20 && !_RB12)
				{
					if(duration < 40)
						SCOPE_DCOffset += 0.001;
					else if(duration < 80)
						SCOPE_DCOffset += 0.01;
					else
						SCOPE_DCOffset += 0.1;
					LCD_ClearPixels(40, 57, 87, 7);
					char * print = floatToBCD(SCOPE_DCOffset, 'V');
					LCD_WriteChars(40, 57, print);
					free(print);
					LCD_Refresh();
					++duration;
				}
			}
			break;
			case 3:
			{
				unsigned char duration = 0;
				while(SCOPE_TriggerValue < 20 && !_RB12)
				{
					if(duration < 40)
						SCOPE_TriggerValue += 0.001;
					else if(duration < 80)
						SCOPE_TriggerValue += 0.01;
					else
						SCOPE_TriggerValue += 0.1;
					LCD_ClearPixels(40, 57, 87, 7);
					char * print = floatToBCD(SCOPE_TriggerValue, 'V');
					LCD_WriteChars(40, 57, print);
					free(print);
					LCD_Refresh();
					++duration;
				}
			}
			break;
			case 4:
			{
				unsigned char duration = 0;
				while(SCOPE_TracerPosition < 1023 && !_RB12)
				{
					if(duration < 20)
						SCOPE_TracerPosition++;
					else if(duration < 40)
						SCOPE_TracerPosition +=8;
					else
						SCOPE_TracerPosition += 32;
					if(SCOPE_TracerPosition > 1023)
						SCOPE_TracerPosition = 1023;
					
					LCD_ClearPixels(40, 57, 87, 7);
					char * print = floatToBCD(SCOPE_Width*SCOPE_TracerPosition/1024, 'S');
					LCD_WriteChars(40, 57, print);
					free(print);
					LCD_ClearPixels(0, 0, 128, 2);
					LCD_WriteBitmap(128.0*SCOPE_TracerPosition/1024-1, 0, 3, 2, LCD_sTracerVert);
					LCD_Refresh();
					++duration;
				}
				if(SCOPE_TracerState)	//if paused.  If not paused, let the ADC_UpdateLCD routine handle it.
					ADC_UpdateTraceVoltage();
			}
			break;
		}
	}
	if(!_RB11 && (PORTB_STATE & 0x0800))	//RIGHT
	{
		switch(MENU_STATE)
		{
			case 0:
                        {
				LCD_WriteBitmap(1,56,7,7,LCD_sW);
				LCD_WriteInvertedBitmap(8,56,6,7,LCD_sH);
				LCD_ClearPixels(40, 57, 87, 7);
				char * print = floatToBCD(SCOPE_Height, 'V');
				LCD_WriteChars(40, 57, print);
				free(print);
				MENU_STATE = 1;
                        }
			break;
			case 1:
                        {
				LCD_WriteBitmap(8,56,6,7,LCD_sH);
				LCD_WriteInvertedBitmap(14,56,7,7,LCD_sV);
				LCD_ClearPixels(40, 57, 87, 7);
				char * print = floatToBCD(SCOPE_DCOffset, 'V');
				LCD_WriteChars(40, 57, print);
				free(print);
				MENU_STATE = 2;
                        }
			break;
			case 2:
                        {
				LCD_WriteBitmap(14,56,7,7,LCD_sV);
				if(SCOPE_TriggerDirection==0)
					LCD_WriteInvertedBitmap(21,56,7,7,LCD_sSIN);
				else if(SCOPE_TriggerDirection==1)
					LCD_WriteInvertedBitmap(21,56,7,7,LCD_sUP);
				else if(SCOPE_TriggerDirection==2)
					LCD_WriteInvertedBitmap(21,56,7,7,LCD_sDOWN);
				LCD_ClearPixels(40, 57, 87, 7);
				char * print = floatToBCD(SCOPE_TriggerValue, 'S');
				LCD_WriteChars(40, 57, print);
				free(print);
				MENU_STATE = 3;
                        }
			break;
			case 3:
                        {
				if(SCOPE_TriggerDirection==0)
					LCD_WriteBitmap(21,56,7,7,LCD_sSIN);
				else if(SCOPE_TriggerDirection==1)
					LCD_WriteBitmap(21,56,7,7,LCD_sUP);
				else if(SCOPE_TriggerDirection==2)
					LCD_WriteBitmap(21,56,7,7,LCD_sDOWN);
					
				if(SCOPE_TracerState)
					LCD_WriteInvertedBitmap(28,56,7,7,LCD_sPAUSE);
				else
					LCD_WriteInvertedBitmap(28,56,7,7,LCD_sPLAY);
				LCD_ClearPixels(40, 57, 87, 7);
				char * print = floatToBCD(SCOPE_Width*SCOPE_TracerPosition/1024, 'V');
				LCD_WriteChars(40, 57, print);
				free(print);
				MENU_STATE = 4;
                        }
			break;
			case 4:
                        {
				if(SCOPE_TracerState)
					LCD_WriteBitmap(28,56,7,7,LCD_sPAUSE);
				else
					LCD_WriteBitmap(28,56,7,7,LCD_sPLAY);
				LCD_WriteInvertedBitmap(1,56,7,7,LCD_sW);
				LCD_ClearPixels(40, 57, 87, 7);
				char * print = floatToBCD(SCOPE_Width, 'S');
				LCD_WriteChars(40, 57, print);
				free(print);
				MENU_STATE = 0;
                        }
			break;
		}
	}
	
	if(!_RB10 && (PORTB_STATE & 0x0400))	//MIDDLE
	{
		if(MENU_STATE == 3)
		{
			SCOPE_TriggerDirection = (SCOPE_TriggerDirection+1)%3;
			if(SCOPE_TriggerDirection==0)
				LCD_WriteInvertedBitmap(21,56,7,7,LCD_sSIN);
			else if(SCOPE_TriggerDirection==1)
			{
				LCD_WriteInvertedBitmap(21,56,7,7,LCD_sUP);
				ADCBUFFERINDEX = 0;
				unsigned int i = 0;
				for(i = 0; i < 1024; ++i)
					ADCBUFFER[i] = 0;
			}
			else if(SCOPE_TriggerDirection==2)
			{
				LCD_WriteInvertedBitmap(21,56,7,7,LCD_sDOWN);
				ADCBUFFERINDEX = 0;
				unsigned int i = 0;
				for(i = 0; i < 1024; ++i)
					ADCBUFFER[i] = 0;
			}
		}
		else if (MENU_STATE == 4)
		{
			if(SCOPE_TracerState)
			{
				LCD_WriteInvertedBitmap(28,56,7,7,LCD_sPLAY);
				SCOPE_TracerState = 0;
				T2CONbits.TON = 1;
			}
			else
			{
				LCD_WriteInvertedBitmap(28,56,7,7,LCD_sPAUSE);
				SCOPE_TracerState = 1;
				T2CONbits.TON = 0;
			}
		}
	}
	
	if(!_RB9 && (PORTB_STATE & 0x0200))     //DOWN
	{
		switch(MENU_STATE)
		{
			case 0:
				if(SCOPE_Width > 0.002) //You start to hit rounding errors, so use 0.002 instead of 0.001.
				{
					SCOPE_Width -= IO_MostSignificantDigitValue(SCOPE_Width-SCOPE_Width/10);
					ADC_SetSamplesPerSecond(1024/SCOPE_Width);
					LCD_ClearPixels(40, 57, 87, 7);
					char * print = floatToBCD(SCOPE_Width, 'S');
					LCD_WriteChars(40, 57, print);
					free(print);
				}
			break;
			case 1:
				if(SCOPE_Height > 1)
				{
					SCOPE_Height--;
					LCD_ClearPixels(40, 57, 87, 7);
					char * print = floatToBCD(SCOPE_Height, 'V');
					LCD_WriteChars(40, 57, print);
					free(print);
				}
			break;
			case 2:
			{
				unsigned char duration = 0;
				while(SCOPE_DCOffset > -20.0 && !_RB9)
				{
					if(duration < 40)
						SCOPE_DCOffset -= .001;
					else if(duration < 80)
						SCOPE_DCOffset -= .01;
					else
						SCOPE_DCOffset -= .1;
					LCD_ClearPixels(40, 57, 87, 7);
					char * print = floatToBCD(SCOPE_DCOffset, 'V');
					LCD_WriteChars(40, 57, print);
					free(print);
					LCD_Refresh();
					++duration;
				}
			}
			break;
			case 3:
			{
				unsigned char duration = 0;
				while(SCOPE_TriggerValue > -20.0 && !_RB9)
				{
					if(duration < 40)
						SCOPE_TriggerValue -= .001;
					else if(duration < 80)
						SCOPE_TriggerValue -= .01;
					else
						SCOPE_TriggerValue -= .1;
					LCD_ClearPixels(40, 57, 87, 7);
					char * print = floatToBCD(SCOPE_TriggerValue, 'V');
					LCD_WriteChars(40, 57, print);
					free(print);
					LCD_Refresh();
					++duration;
				}
			}
			break;
			case 4:
			{
				unsigned char duration = 0;
				while(SCOPE_TracerPosition > 0 && !_RB9)
				{
					if(duration < 20)
						SCOPE_TracerPosition--;
					else if(duration < 40)
						SCOPE_TracerPosition -=8;
					else
						SCOPE_TracerPosition -= 32;
					if(SCOPE_TracerPosition < 0)
						SCOPE_TracerPosition = 0;
					LCD_ClearPixels(40, 57, 87, 7);
					char * print = floatToBCD(SCOPE_Width*SCOPE_TracerPosition/1024, 'S');
					LCD_WriteChars(40, 57, print);
					free(print);
					LCD_ClearPixels(0, 0, 128, 2);
					LCD_WriteBitmap(128.0*SCOPE_TracerPosition/1024-1, 0, 3, 2, LCD_sTracerVert);
					LCD_Refresh();
					++duration;
				}
				if(SCOPE_TracerState)	//if paused.  If not paused, let the ADC_UpdateLCD routine handle it.
					ADC_UpdateTraceVoltage();
			}
			break;
		}
	}
	if(!_RB8 && (PORTB_STATE & 0x0100))	//LEFT
	{
		switch(MENU_STATE)
		{
			case 0:
			{
				LCD_WriteBitmap(1,56,7,7,LCD_sW);
				if(SCOPE_TracerState)
					LCD_WriteInvertedBitmap(28,56,7,7,LCD_sPAUSE);
				else
					LCD_WriteInvertedBitmap(28,56,7,7,LCD_sPLAY);
				LCD_ClearPixels(40, 57, 87, 7);
				char * print = floatToBCD(SCOPE_Width*SCOPE_TracerPosition/1024, 'S');
				LCD_WriteChars(40, 57, print);
				free(print);
				MENU_STATE = 4;
			}
			break;
			case 1:
			{
				LCD_WriteBitmap(8,56,6,7,LCD_sH);
				LCD_WriteInvertedBitmap(1,56,7,7,LCD_sW);
				LCD_ClearPixels(40, 57, 87, 7);
				char * print = floatToBCD(SCOPE_Width, 'S');
				LCD_WriteChars(40, 57, print);
				free(print);
				MENU_STATE = 0;
			}
			break;
			case 2:
			{
				LCD_WriteBitmap(14,56,7,7,LCD_sV);
				LCD_WriteInvertedBitmap(8,56,6,7,LCD_sH);
				LCD_ClearPixels(40, 57, 87, 7);
				char * print = floatToBCD(SCOPE_Height, 'V');
				LCD_WriteChars(40, 57, print);
				free(print);
				MENU_STATE = 1;
			}
			break;
			case 3:
			{
				if(SCOPE_TriggerDirection==0)
					LCD_WriteBitmap(21,56,7,7,LCD_sSIN);
				else if(SCOPE_TriggerDirection==1)
					LCD_WriteBitmap(21,56,7,7,LCD_sUP);
				else if(SCOPE_TriggerDirection==2)
					LCD_WriteBitmap(21,56,7,7,LCD_sDOWN);
				LCD_WriteInvertedBitmap(14,56,7,7,LCD_sV);	
				LCD_ClearPixels(40, 57, 87, 7);
				char * print = floatToBCD(SCOPE_DCOffset, 'V');
				LCD_WriteChars(40, 57, print);
				free(print);
				MENU_STATE = 2;
			}
			break;
			case 4:
            {
				if(SCOPE_TriggerDirection==0)
					LCD_WriteInvertedBitmap(21,56,7,7,LCD_sSIN);
				else if(SCOPE_TriggerDirection==1)
					LCD_WriteInvertedBitmap(21,56,7,7,LCD_sUP);
				else if(SCOPE_TriggerDirection==2)
					LCD_WriteInvertedBitmap(21,56,7,7,LCD_sDOWN);	
					
				if(SCOPE_TracerState)
					LCD_WriteBitmap(28,56,7,7,LCD_sPAUSE);
				else
					LCD_WriteBitmap(28,56,7,7,LCD_sPLAY);
				
				LCD_ClearPixels(40, 57, 87, 7);
				char * print = floatToBCD(SCOPE_TriggerValue, 'S');
				LCD_WriteChars(40, 57, print);
				free(print);
				MENU_STATE = 3;
            }
			break;
		}
	}
	PORTB_STATE = PORTB;
    _CNIF = 0;  //clear interrupt flag
}
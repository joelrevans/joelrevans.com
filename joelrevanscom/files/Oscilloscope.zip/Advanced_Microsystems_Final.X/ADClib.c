char * floatToBCD(float input, char postfix);
int SCOPE_TracerPosition;
void LCD_WriteChars(unsigned char x, unsigned char y, char * input);
unsigned char SCOPE_TriggerDirection;
char LCD_sPAUSE[];
unsigned char SCOPE_TracerState;

float ADCBUFFER[1024];
unsigned int ADCBUFFERINDEX;
unsigned int ADC_Samples_Per_Sec;

float SCOPE_DCOffset;
float SCOPE_Height;

char ADC_TriggerType;	//0 : rolling;  1 : L->H;  2: H->L
float ADC_TriggerLevel = 0;

float ADC_LastVoltageReading;	//used to handle triggers.

void ADC_SetSamplesPerSecond(unsigned int sps)
{
	ADC_Samples_Per_Sec = sps;
	unsigned long period = 16000000UL / sps;
	PR2 = period;		//least significant int
	PR3 = period>>16;	//most significant int
	TMR2 = 0;
	TMR3 = 0;
}

void ADC_Init()
{
	AD1CHS = 0;			//AN0 = _RB1
	_TRISB0 = 1;		//_RB1 is an input
	
	_SSRC = 0b111;		//Internal counter manages ADC timing
	_ASAM = 1;			//Sampling begins after last conversion completes, auto sets SAMP bit.
	AD1CON3 = 0x1F01;   // sample time=31Tad, Tad=2xTcy=125ns
	
	_ADON = 1;			//turn ADC on
	
	//Init TIMER
	TMR2 = 0;
	TMR3 = 0;
	T2CONbits.T32 = 1;		//Timer2 and Timer3 form a single 32-bit timer.
	ADC_SetSamplesPerSecond(1000);
	IEC0bits.T3IE = 1;
	T2CONbits.TON = 1;
}

void ADC_UpdateTraceVoltage()
{
	LCD_ClearPixels(80, 57, 48, 7);
	char * print = floatToBCD(ADCBUFFER[(ADCBUFFERINDEX+SCOPE_TracerPosition)%1024], 'V');
	LCD_WriteChars(80, 57, print);
	free(print);
}

void ADC_UpdateLCD()
{
	//y bounds 2-54
	//x bounds 0-128
	
	unsigned char x;
	unsigned char i;
	float max;
	float min;
	
	for(x = 0; x < 128; ++x)
	{
		max = FLT_MIN;
		min = FLT_MAX;
		for(i = 0; i < 8; ++i)
		{
			unsigned int tmp = (ADCBUFFERINDEX+x*8+i)%1024;
			if(ADCBUFFER[tmp]>max)
				max=ADCBUFFER[tmp];
			if(ADCBUFFER[tmp]<min)
				min=ADCBUFFER[tmp];
		}
		
		long bartop = (max-SCOPE_DCOffset)/(SCOPE_DCOffset+SCOPE_Height)*52+2;
		long barbot = (min-SCOPE_DCOffset)/(SCOPE_DCOffset+SCOPE_Height)*52+2;
		
		for(i = 2; i < 54; ++i)	//reusing i
		{
			if(i >= barbot && i <= bartop)
				LCD_SetPixel(x, i);
			else
				LCD_ClearPixel(x, i);
		}
	}
	
	ADC_UpdateTraceVoltage();
}

void __attribute__ ((interrupt, auto_psv)) _T3Interrupt ( void)
{
	float currentVoltageReading = 3.3*ADC1BUF0/1024;
	if(SCOPE_TriggerDirection == 0)
	{
		ADCBUFFER[ADCBUFFERINDEX] = currentVoltageReading;
		if(ADCBUFFERINDEX >= 1023)
			ADCBUFFERINDEX = 0;
		else
			ADCBUFFERINDEX++;
	}
	else if(SCOPE_TriggerDirection == 1)	//up
	{
		if(ADC_LastVoltageReading <= ADC_TriggerLevel && currentVoltageReading > ADC_TriggerLevel && ADCBUFFERINDEX == 0)
		{
			ADCBUFFER[0] = currentVoltageReading;
			ADCBUFFERINDEX = 1;
		}
		else if (ADCBUFFERINDEX != 0)
		{
			ADCBUFFER[ADCBUFFERINDEX] = currentVoltageReading;
			if(ADCBUFFERINDEX > 1023)
			{
				SCOPE_TracerState = 1;
				LCD_WriteInvertedBitmap(28,56,7,7,LCD_sPAUSE);
				ADCBUFFERINDEX = 0;
				T2CONbits.TON = 0;
			}
			ADCBUFFERINDEX++;
		}
	}
	else if(SCOPE_TriggerDirection == 2)	//down
	{
		if(ADC_LastVoltageReading >= ADC_TriggerLevel && currentVoltageReading < ADC_TriggerLevel && ADCBUFFERINDEX == 0)
		{
			ADCBUFFER[0] = currentVoltageReading;
			ADCBUFFERINDEX = 1;
		}
		else if (ADCBUFFERINDEX != 0)
		{
			ADCBUFFER[ADCBUFFERINDEX] = currentVoltageReading;
			if(ADCBUFFERINDEX > 1023)
			{
				SCOPE_TracerState = 1;
				LCD_WriteInvertedBitmap(28,56,7,7,LCD_sPAUSE);
				ADCBUFFERINDEX = 0;
				T2CONbits.TON = 0;
			}
			ADCBUFFERINDEX++;
		}
	}
	
	ADC_LastVoltageReading = currentVoltageReading;
	IFS0bits.T3IF = 0;
}
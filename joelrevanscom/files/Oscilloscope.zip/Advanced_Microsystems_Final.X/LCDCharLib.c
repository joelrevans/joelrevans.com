#include <stdlib.h>

//All #'s are 4x5
char LCD_c1[] = 
{
0b11001001,
0b00101110
};
char LCD_c2[] = 
{
0b01100001,
0b01101000,
0b11110000
};
char LCD_c3[]=
{
0b11100001,
0b01100001,
0b11100000
};
char LCD_c4[]=
{
0b10011001,
0b01110001,
0b00010000
};
char LCD_c5[]=
{
0b11111000,
0b01100001,
0b11100000
};
char LCD_c6[]=
{
0b01111000,
0b11101001,
0b01100000
};
char LCD_c7[]=
{
0b11110001,
0b00010010,
0b00100000
};
char LCD_c8[]=
{
0b01101001,
0b01101001,
0b01100000
};
char LCD_c9[]=
{
0b01101001,
0b01110001,
0b00010000
};
char LCD_c0[]=
{
0b01101001,
0b10011001,
0b01100000
};
//5x5
char LCD_cW[]=
{
0b10001100,
0b01100011,
0b01010101,
0b00000000
};
//4x5
char LCD_cH[]=
{
0b10011001,
0b11111001,
0b10010000
};
//5x5
char LCD_cV[]=
{
0b10001100,
0b01100010,
0b10100010,
0b00000000
};
//5x5
char LCD_cT[]=
{
0b11111001,
0b00001000,
0b01000010,
0b00000000
};
//5x5
char LCD_c_[]=
{
	0b00000000,
	0b00000000,
	0b00000000,
	0b00000000
};
//5x5
char LCD_cS[]=
{
	0b01110100,
	0b00011100,
	0b00011111,
	0b00000000
};
//5x5
char LCD_cMINUS[]=
{
	0b00000000,
	0b00011100,
	0b00000000,
	0b00000000
};

char * floatToBCD(float input, char postfix)
{
        char * retval = malloc(9);
        unsigned int i = 0;
        
        if(input < 0)
	{
            retval[i++] = '-';
            input *= -1.0;
	}
        
	unsigned char tens = ((unsigned int)(input/10))%10;
	unsigned char ones = ((unsigned int)input)%10;
	unsigned char tenths = ((unsigned int)(input/.1))%10;
	unsigned char hundredths = ((unsigned int)(input/.01))%10;
	unsigned char thousandths = ((unsigned int)(input/.001))%10;
	
	if(tens)
		retval[i++] = '0'+tens;
	if(ones)
		retval[i++] = '0'+ones;
	retval[i++] = '.';
	retval[i++] = '0'+tenths;
	retval[i++] = '0'+hundredths;
	retval[i++] = '0'+thousandths;
	if(postfix)
		retval[i++] = postfix;
	retval[i] = 0;
	
	return retval;
}

void LCD_WriteChars(unsigned char x, unsigned char y, char * string)
{
	char * selected = string;
	while(*selected != 0)
	{
		switch(*selected)
		{
			case '0':
			LCD_WriteBitmap(x, y, 4, 5, LCD_c0);
			x+=5;
			break;
			case '1':
			LCD_WriteBitmap(x, y, 3, 5, LCD_c1);
			x+=4;
			break;
			case '2':
			LCD_WriteBitmap(x, y, 4, 5, LCD_c2);
			x+=5;
			break;
			case '3':
			LCD_WriteBitmap(x, y, 4, 5, LCD_c3);
			x+=5;
			break;
			case '4':
			LCD_WriteBitmap(x, y, 4, 5, LCD_c4);
			x+=5;
			break;
			case '5':
			LCD_WriteBitmap(x, y, 4, 5, LCD_c5);
			x+=5;
			break;
			case '6':
			LCD_WriteBitmap(x, y, 4, 5, LCD_c6);
			x+=5;
			break;
			case '7':
			LCD_WriteBitmap(x, y, 4, 5, LCD_c7);
			x+=5;
			break;
			case '8':
			LCD_WriteBitmap(x, y, 4, 5, LCD_c8);
			x+=5;
			break;
			case '9':
			LCD_WriteBitmap(x, y, 4, 5, LCD_c9);
			x+=5;
			break;
			case '.':
			LCD_SetPixel(x, y);
			x+=2;
			break;
			case 'V':
			LCD_WriteBitmap(x, y, 5, 5, LCD_cV);
			x+=6;
			break;
			case ' ':
			LCD_WriteBitmap(x, y, 5, 5, LCD_c_);
			x+=6;
			break;
			case 'S':
			LCD_WriteBitmap(x, y, 5, 5, LCD_cS);
			x+=6;
			break;
			case '-':
			LCD_WriteBitmap(x, y, 5, 5, LCD_cMINUS);
			x+=6;
			break;
		}
		selected++;
	}
}

//7x7
char LCD_sT[]=
{
0b00000000,
0b11111000,
0b01000000,
0b10000001,
0b00000010,
0b00000000,
0b00000000
};
//7x7
char LCD_sUP[]=
{
0b00000000,
0b00100000,
0b11100011,
0b11100001,
0b00000010,
0b00000000,
0b00000000
};
//7x7
char LCD_sDOWN[]=
{
0b00000000,
0b00100000,
0b01000011,
0b11100011,
0b10000010,
0b00000000,
0b00000000
};
//7x7
char LCD_sSIN[]=
{
0b00000000,
0b01001001,
0b01010010,
0b10100101,
0b01001001,
0b00000000,
0b00000000
};
//7x7
char LCD_sW[]=
{
0b00000000,
0b10001001,
0b00010010,
0b00100101,
0b01000101,
0b00000000,
0b00000000
};
//6x7
char LCD_sH[]=
{
0b00000001,
0b00100100,
0b10011110,
0b01001001,
0b00100000,
0b00000000
};
//7x7
char LCD_sV[]=
{
0b00000000,
0b10001001,
0b00010010,
0b00100010,
0b10000010,
0b00000000,
0b00000000
};
//3x2
char LCD_sTracerVert[]=
{
	0b01011100
};
//2x3
char LCD_sTriggerHorz[]=
{
	0b01110100
};
//7x7
char LCD_sPLAY[]=
{
	0b00000000,
	0b10000001,
	0b11000011,
	0b11100111,
	0b00001000,
	0b00000000,
	0b00000000
};
//7x7
char LCD_sPAUSE[]=
{
0b00000000,
0b11011001,
0b10110011,
0b01100110,
0b11001101,
0b10000000,
0b00000000
};


/* 
 * File:   main.c
 * Author: JOEL EVANS
 * Created on March 15, 2013, 3:20 PM
 */
#include <p24FJ256GB106.h>
#include <float.h>
#include <stdlib.h>
#include "LCDlib_2.c"
#include "ADClib.c"
#include "LCDCharLib.c"
#include "UIlib.c"

/*LCDLIB_1 uses a read-modify-write method that is very slow for updating large portions of the screen.
 LCDLIB_2 uses a buffer-based approach that dumps to the screen when "refresh" is called.*/

int main()
{
   SCOPE_Width = 1;
   SCOPE_Height = 3.3;

    LCD_Init();
    UI_InitButtons();
    ADC_Init();
    while(1)
    {
        LCD_Refresh();
        ADC_UpdateLCD();
    }
}



#ifndef UARTLIB_C
#define UARTLIB_C

#include <p24FJ256GB106.h>

void UART1_Init()
{
    _TRISF0 = 0;                //Reset = output
    _TRISG6 = 1;                //Recieve = input
    _TRISG7 = 0;                //Transmit = output
	
	//RESET UART to USB converter.
	_RF0 = 0;					//Hold low for 15uS to reset.
	T2CONbits.TON = 1;
	TMR2 = 0;	
	while(TMR2 < 240);			//15uS
	_RF0 = 1;
	
    _U1RXR = 21;                //Set UART1_Rx to _G6 = RP21.
    RPOR11 = 3;                 //Set UART1_Tx pin to _G7 = RP26.

    U1MODEbits.UEN = 0b00;      //Tx and Rx pins are only used.
    U1MODEbits.RTSMD = 1;       //SIMPLEX MODE.
    U1MODEbits.BRGH = 1;        //High speed baud mode.  Uses 4Mhz clock.
    U1MODEbits.PDSEL = 0b00;    //8-bit data, no parity.
    U1MODEbits.STSEL = 0;       //Use a single stop-bit.
    //U1BRG = 7;                  //16Mhz clock / (7+1) = baud rate of 500k.  Equation in datasheet.
    U1BRG = 417;                //9600 baud.

    U1MODEbits.UARTEN = 1;      //enable UART module.
    U1STAbits.UTXEN = 1;        //Enable UART transmit.
}

void UART1_Transmit(char data)
{
	U1STAbits.UTXEN = 1;        //Enable UART transmit.
	U1TXREG = data;
	U2STAbits.UTXBF;
}

#endif
#ifndef LCDLIB_C
#define LCDLIB_C

#include <p24FJ256GB106.h>
#define LCD_Clock()     TMR1 = 0; while(TMR1 < 7); _RD5 = !_RD5; while(TMR1 < 15) _RD5 = !_RD5;

char LCD_Execute(char data, char instruction, char write)
{
    _RD4 = !write;
    _RB15 = !instruction;

    if(write)
    {
        TRISE = 0;
        LATE = data;
        LCD_Clock();
        LCD_Clock();    //Adding a second clock fixes things.  Just dont ask how.
        return 0;
    }
    else
    {
        TRISE = ~0;
        LCD_Clock();
        LCD_Clock();
        return PORTE;
    }
}

void LCD_Init()
{
    T1CONbits.TON = 1;

    TRISE=0x00;             //PORTE acts as your data I/O to the LCD
    TRISBbits.TRISB15 = 0;  //1 = DATA, 0 = COMMAND
    TRISDbits.TRISD2 = 0;   //Hardware RESET.  Operation on 0.  Requires delay.
    TRISDbits.TRISD4 = 0;   //1=READ, 0=WRITE
    TRISDbits.TRISD5 = 0;   //LCD CLOCK
    TRISDbits.TRISD11 = 0;  //LCD DRIVER SELECT;  1=LEFT, 0=RIGHT

    _RD2=0;                 //LCD hardware reset
    LCD_Clock();
    _RD2=1;
    LCD_Clock();
    _RD11 = !_RD11;         //The display runs on two 64x64 drivers, so you have to update each.
    _RD2 = 0;
    LCD_Clock();
    _RD2=1;

    while(LCD_Execute(0, 1, 0) & 0b00010000)        //Check for reset complete.
    _RD11 = !_RD11;
    while(LCD_Execute(0, 1, 0) & 0b00010000)        //Check the other driver

    //AFAIK, you need to turn it off before it can be turned on after a reset.
    LCD_Execute(0b00111110, 1, 1);                  //turn LCD display off
    LCD_Execute(0b00111111, 1, 1);                  //turn LCD display on
    _RD11 = !_RD11;
    LCD_Execute(0b00111110, 1, 1);
    LCD_Execute(0b00111111, 1, 1);

    while(LCD_Execute(0, 1, 0) & 0b00100000);       //Check for LCD turned on.
    _RD11 = !_RD11;
    while(LCD_Execute(0, 1, 0) & 0b00100000);
}

void LCD_ClearPixel(unsigned char x, unsigned char y)
{
    x%=128;
    y%=64;
    if(x > 63)
    {
        _RD11 = 0;  //Right side
        x-=64;
    }
    else
        _RD11 = 1;  //Left side

    //X and y on this are on each others axes, and need to be reoriented.
    LCD_Execute(0b10111000 | (y >> 3), 1, 1);   //Set the X address.
    LCD_Execute(0b01000000 | x, 1, 1);          //Set the Y address.
    char data = LCD_Execute(0, 0, 0);           //Read the display memory.
    data &= ~(1 << (y%8));                      //Edit the specified bit.
    LCD_Execute(0b10111000 | (y >> 3), 1, 1);   //Set the X address.
    LCD_Execute(0b01000000 | x, 1, 1);          //Set the Y address.
    LCD_Execute(data, 0, 1);                    //Write data back into memory.
}

void LCD_SetPixel(unsigned char x, unsigned char y)
{
    x%=128;
    y%=64;
    if(x > 63)
    {
        _RD11 = 0;  //Right side
        x-=64;
    }
    else
        _RD11 = 1;  //Left side

    //X and y on this are on each others axes, and need to be reoriented.
    LCD_Execute(0b10111000 | (y >> 3), 1, 1);   //Set the X address.
    LCD_Execute(0b01000000 | x, 1, 1);          //Set the Y address.
    char data = LCD_Execute(0, 0, 0);           //Read the display memory.
    data |= 1 << (y%8);                      //Edit the specified bit.
    LCD_Execute(0b10111000 | (y >> 3), 1, 1);   //Set the X address.
    LCD_Execute(0b01000000 | x, 1, 1);          //Set the Y address.
    LCD_Execute(data, 0, 1);                    //Write data back into memory.
}

#endif
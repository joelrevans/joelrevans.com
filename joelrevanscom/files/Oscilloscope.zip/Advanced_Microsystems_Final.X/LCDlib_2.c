#ifndef LCDLIB_C
#define LCDLIB_C

#include <p24FJ256GB106.h>
#define LCD_Clock()     Nop();Nop();Nop();Nop();Nop();_RD5=!_RD5;Nop();Nop();Nop();Nop();Nop();_RD5=!_RD5;

char displayBuffer[128*64/8];

char LCD_Execute(char data, char instruction, char write)
{
    _RD4 = !write;
    _RB15 = !instruction;

    if(write)
    {
        TRISE = 0;
        LATE = data;
        LCD_Clock();    //Adding a second clock fixes things.  Just dont ask how.
        return 0;
    }
    else
    {
        TRISE = ~0;
        LCD_Clock();
        LCD_Clock();
        return PORTE;
    }
}

void LCD_Send(char data, char instruction)
{
    _RB15 = !instruction;
    LATE = data;
    LCD_Clock();
}

void LCD_Init()
{
    TRISE=0x00;             //PORTE acts as your data I/O to the LCD
    TRISBbits.TRISB15 = 0;  //1 = DATA, 0 = COMMAND
    TRISDbits.TRISD2 = 0;   //Hardware RESET.  Operation on 0.  Requires delay.
    TRISDbits.TRISD4 = 0;   //1=READ, 0=WRITE
    TRISDbits.TRISD5 = 0;   //LCD CLOCK
    TRISDbits.TRISD11 = 0;  //LCD DRIVER SELECT;  1=LEFT, 0=RIGHT

    _RD2=0;                 //LCD hardware reset
    LCD_Clock();
    _RD2=1;
    LCD_Clock();
    _RD11 = !_RD11;         //The display runs on two 64x64 drivers, so you have to update each.
    _RD2 = 0;
    LCD_Clock();
    _RD2=1;

    while(LCD_Execute(0, 1, 0) & 0b00010000)        //Check for reset complete.
    _RD11 = !_RD11;
    while(LCD_Execute(0, 1, 0) & 0b00010000)        //Check the other driver

    //AFAIK, you need to turn it off before it can be turned on after a reset.
    LCD_Execute(0b00111110, 1, 1);                  //turn LCD display off
    LCD_Execute(0b00111111, 1, 1);                  //turn LCD display on
    _RD11 = !_RD11;
    LCD_Execute(0b00111110, 1, 1);
    LCD_Execute(0b00111111, 1, 1);

    while(LCD_Execute(0, 1, 0) & 0b00100000);       //Check for LCD turned on.
    _RD11 = !_RD11;
    while(LCD_Execute(0, 1, 0) & 0b00100000);
    
    TRISE = 0;	//output
    _RD4 = 0;	//write
}

void LCD_Refresh()
{
    int x;
    int y;
    _RD11 = 1;
    LCD_Send(0b01000000, 1);
    _RD11 = 0;
    LCD_Send(0b01000000, 1);
    for(y = 0; y < 8; ++y)
    {
            _RD11 = 1;
            Nop();
            LCD_Send(0b10111000 | y, 1);
            for(x = 0; x < 64; ++x)
                    LCD_Send(displayBuffer[x+y*128], 0); 	//Write data into memory.
            _RD11 = 0;
            Nop();
            LCD_Send(0b10111000 | y, 1);
            for(x = 64; x < 128; ++x)
                    LCD_Send(displayBuffer[x+y*128], 0); 	//Write data into memory.
            Nop();
    }
}

void LCD_ClearPixel(unsigned char x, unsigned char y)
{
    x%=128;
    y%=64;
    displayBuffer[x+(7-y/8)*128] &= ~(0x80>>(y%8));
}

void LCD_SetPixel(unsigned char x, unsigned char y)
{
    x%=128;
    y%=64;
    displayBuffer[x+(7-y/8)*128] |= 0x80>>(y%8);
}

void LCD_WriteBitmap(unsigned char x, unsigned char y, unsigned char width, unsigned char height, char * data)
{
	char startX = x;
	char startY = y;
	x = 0;
	y = 0;
        unsigned char i = 0;

        for(i=0; i < width * height; ++i)
        {
            if(data[i/8]&(1<<(7-i%8)))
                LCD_SetPixel(startX+i%width,startY+height-1-i/width);
            else
                LCD_ClearPixel(startX+i%width,startY+height-1-i/width);
        }
}

void LCD_WriteInvertedBitmap(unsigned char x, unsigned char y, unsigned char width, unsigned char height, char * data)
{
	char startX = x;
	char startY = y;
	x = 0;
	y = 0;
	unsigned int i = 0;

	for(i=0; i < width * height; ++i)
	{
		if(data[i/8]&(1<<(7-i%8)))
			LCD_ClearPixel(startX+i%width,startY+height-1-i/width);
		else
			LCD_SetPixel(startX+i%width,startY+height-1-i/width);
	}
}

void LCD_ClearPixels(unsigned char x, unsigned char y, unsigned char width, unsigned char height)
{
	unsigned char ytemp = y;
	unsigned char xMax = x + width;
	unsigned char yMax = y + height;
	while(x < xMax)
	{
		for(y = ytemp; y < yMax; ++y)
			LCD_ClearPixel(x, y);
		++x;
	}
}

#endif
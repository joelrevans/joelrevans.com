
/*Returns the integer value of the logarithm, base 2, of a number.*/
unsigned int log2int(unsigned int number){
    for(unsigned int i = 0; i < 32; i++){
        if(number)
            number >>= 1;
        else
            return i;
    }
}

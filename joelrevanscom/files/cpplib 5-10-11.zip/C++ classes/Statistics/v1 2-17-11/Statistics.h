
class Statistics{

    public:

    /*Returns the variance of a set of numbers corresponding to any fundamental data type.*/
    template<class T>
    static double Variance(T * members, unsigned int const &length){

        double sum = 0;
        double sumSquares = 0;

        T opvar;

        for(unsigned int i = 0; i < length; ++i){
            opvar = members[i];
            sum += opvar;
            sumSquares += opvar * opvar;
        }

        return sum * sum - sumSquares;
    }

}

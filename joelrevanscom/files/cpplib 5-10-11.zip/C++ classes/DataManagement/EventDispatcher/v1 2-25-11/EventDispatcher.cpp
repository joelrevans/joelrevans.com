#include "SinglyLinkedList.cpp"

template<class T>
class EventDispatcher{

    private:

    SinglyLinkedList<void (*)(T)>listeners;

    public:

    EventDispatcher(){
        listeners = *(new SinglyLinkedList<void (*)(T)>());
    }

    void AddListener(void (*method)(T passVar)){
        listeners.prepend(method);
    }

    void RemoveListener(void (*method)(T remoVar)){
        unsigned int dex = listeners.searchSingle(method);
        listeners.remove(dex);
    }

    bool isListening(void (*method)(T remoVar)){
        return listeners.searchSingle(method) == listeners.getLength() ? false : true;
    }

    void dispatchEvent(T passData){
        for(unsigned int i = 0; i < listeners.getLength(); ++i){ //yeah, yeah, i know it's slow.
            (*(listeners.get(i)))(passData);
        }
    }

    unsigned int numListeners(){
        return listeners.getLength();
    }

};
template<>
class EventDispatcher<void>{

    private:

    SinglyLinkedList<void (*)()> listeners;

    public:

    EventDispatcher(){
        listeners = *(new SinglyLinkedList<void (*)()>());
    }

    void AddListener(void (*method)()){
        listeners.prepend(method);
    }

    void RemoveListener(void (*method)()){
        unsigned int dex = listeners.searchSingle(method);
        listeners.remove(dex);
    }

    bool isListening(void (*method)()){
        return listeners.searchSingle(method) == listeners.getLength() ? false : true;
    }

    void dispatchEvent(){
        for(unsigned int i = 0; i < listeners.getLength(); ++i){ //yeah, yeah, i know it's slow.
            (listeners.get(i))();
        }
    }

    unsigned int numListeners(){
        return listeners.getLength();
    }

};

#ifndef EVENTDISPATCHER_CPP
#define EVENTDISPATCHER_CPP

#include "CircularList.cpp"

template<class T>
class EventDispatcher{

    private:

    CircularList<void (*)(T)>listeners;

    public:

    EventDispatcher(){
        listeners = *(new CircularList<void (*)(T)>());
    }

    void AddListener(void (*method)(T passVar)){
        listeners.insert(method);
    }

    void RemoveListener(void (*method)(T remoVar)){
        listeners.gotoItem(method);
        listeners.remove();
    }

    bool isListening(void (*method)(T remoVar)){
        return listeners.gotoItem(method);
    }

    void dispatchEvent(T passData){
        for(unsigned int i = 0; i < listeners.getLength(); ++i){ //yeah, yeah, i know it's slow.
            (*(listeners.get()))(passData);
            listeners.next();
        }
    }

    unsigned int numListeners(){
        return listeners.getLength();
    }

};

template<>
class EventDispatcher<void>{

    private:

    CircularList<void (*)()> listeners;

    public:

    EventDispatcher(){
        listeners = *(new CircularList<void (*)()>());
    }

    void AddListener(void (*method)()){
        listeners.insert(method);
    }

    void RemoveListener(void (*method)()){
        listeners.gotoItem(method);
        listeners.remove();
    }

    bool isListening(void (*method)()){
        return listeners.gotoItem(method);
    }

    void dispatchEvent(){
        for(unsigned int i = 0; i < listeners.getLength(); ++i){ //yeah, yeah, i know it's slow.
            (listeners.get())();
            listeners.next();
        }
    }

    unsigned int numListeners(){
        return listeners.getLength();
    }

};

#endif

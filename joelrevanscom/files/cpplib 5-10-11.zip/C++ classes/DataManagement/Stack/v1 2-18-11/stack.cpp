#ifndef STACK_CPP
#define STACK_CPP


template <class T>
class Stack{

    private :

    unsigned int length;

    struct Linker{
        Linker * next;
        T data;
    };

    Linker * terminal;

    public:

    /*Instantiates the stack.*/
   /* void Stack(){
        //length = 0;
    }*/

    /*Adds an item to the end of the stack.*/
    void push(T object){
        Linker * temp = terminal;
        terminal = new Linker();
        (*terminal).next = temp;
        (*terminal).data = object;
        ++length;
    }

    /*Removes the stack terminal.*/
    void pop(){
        Linker * temp = (*terminal).next;
        delete terminal;
        terminal = temp;
        --length;
    }

    /*Returns a pointer to the current stack terminal.*/
    T get(){
        return (*terminal).data;
    }

    /*Returns the stack as an array of items, with the terminal at (index=0)*/
    T * toArray(){
        T * output = new T[length];
        Linker * current = terminal;

        for(unsigned int i = 0; i < length; ++i){
            output[i] = (*current).data;
            current = (*current).next;
        }

        return output;
    }

    /*Returns the number of items on the stack.*/
    unsigned int const getLength(){
        return length;
    }
};
#endif

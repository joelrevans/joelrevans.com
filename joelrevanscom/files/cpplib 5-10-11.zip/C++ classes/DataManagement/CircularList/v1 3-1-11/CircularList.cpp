#ifndef CIRCULARLIST_CPP
#define CIRCULARLIST_CPP

template<class T>
class CircularList{

    private:

    struct Linker{
        Linker * next;
        Linker * prev;
        T data;
        Linker(T dat, Linker * prv = 0, Linker * nxt = 0):data(dat), next(nxt), prev(prv){}
    };

    unsigned int length;

    Linker * current;

    public:

    CircularList(){
        length = 0;
    }

    /*Will cycle through the list until an item equal to the input is found.  If no input is found, will reset to the previous state.*/
    bool gotoItem(T input){
        unsigned int i = length;
        while(i--){
            if(current->data == input)
                return true;
            next();
        }
        return false;
    }

    /*Inserts an object after the current one.*/
    void insert(T data){
        if(length){
            Linker * tmp = new Linker(data, current, current->next);
            (current->next)->prev = tmp;
            current->next = tmp;
        }else{
            current = new Linker(data, 0, 0);
            current->next = current->prev = current;
        }
        ++length;
    }

    /*Removes the current object, and cycles forward to the next object.*/
    void remove(){
        (current->prev)->next = current->next;
        (current->next)->prev = current->prev;
        Linker * tmp = current->next;
        delete current;
        current = tmp;
        --length;
    }

    /*Cycles ahead to the next object.*/
    inline void next(){
        current = current->next;
    }

    /*Cycles backwars to the previous object.*/
    inline void previous(){
        current = current->prev;
    }

    /*Returns the currently selected object.*/
    inline T get(){
        return current->data;
    }

    /*Returns the number of objects in the array.*/
    inline unsigned int getLength(){
        return length;
    }

    ~CircularList(){
        Linker * temp;
        while(length){
            temp = current->next;
            delete current;
            current = temp;
            --length;
        }
    }

};

#endif

class LinkedList{
    public:
    struct Linker{
        Linker * next;
        void * pointer;
    };
    unsigned int length;
    Linker * head;
    LinkedList(){
        head = 0;
        length = 0;
    }
    ~LinkedList(){
        Linker *current = head;
        Linker *prev;
        for(unsigned int i = 0; i < length; i++){
            prev = current;
            current = (*current).next;
            delete prev;
        }
        delete current; //needed to delete the last element
    }
    void add(unsigned int index, void * pointer){
        Linker * s = new Linker;
        (*s).pointer = pointer;
        if(index){
            Linker * current = head;
            for(unsigned i = 0; i < index-1; i++){
                current = (*current).next;
            }
            (*s).next = (*current).next;
            (*current).next = s;
        }else{
            (*s).next = head;
            head = s;
        }
        length++;
    }
    void remove(unsigned int index){
        Linker * current = head;
        if(index){
            for(unsigned i = 1; i < index; i++){
                current = (*current).next;
            }
            Linker * prev = current;             //Stores the last linker
            current = (*current).next;          //Advances to the linker to be deleted
            Linker *temp = (*current).next;     //Gets the next linker
            (*prev).next = temp;                //Patches up the hole where current used to be
            delete current;                     //Deletes current
        }else{
            current = (*head).next;
            delete head;
            head = current;
        }
        length--;
    }
    void * get(unsigned int index){
        Linker *current = head;
        for(unsigned int i = 0; i < index; i++){
            current = (*current).next;
        }
        return (*current).pointer;
    }
};

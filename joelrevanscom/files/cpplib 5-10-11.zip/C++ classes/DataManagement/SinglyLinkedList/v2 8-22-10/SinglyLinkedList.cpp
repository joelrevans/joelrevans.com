
template<class T>
class SinglyLinkedList{
    private:
    struct Linker{
        Linker * next;
        T * data;
        Linker(T * dat, Linker * nxt = 0):data(dat), next(nxt){}   //This is like a constructor for a struct, so you can initialize on the heap.
    };
    /*A pointer to the first element in the list.*/
    Linker * foot;
    /*Holds the length of the list.*/
    unsigned int length;

    public:
    SinglyLinkedList(){
        length = 0;
        foot = 0;
    }
    /*Constructor for the SinglyLinkedList object.*/
    SinglyLinkedList(T * item){     //Tested!
        foot = new Linker(item);
        length=1;
    }
    /*Constructor for the SinglyLinkedList object.  Accepts an array, and the given array's length.*/
    SinglyLinkedList(T * item, unsigned int const &arrayLength){    //Tested!
        Linker * current;
        foot = current = new Linker(item);
        for(unsigned int i = 1; i < arrayLength; ++i)
        current = current->next = new Linker(item + i); //See insert for comments on this line.
        length = arrayLength;
    }

    /*Returns the length of the list.*/
    inline unsigned int getLength() const{  //Tested!
        return length;
    }
    /*Returns the item from a specified index.*/
    T * get(unsigned int const &index){     //Tested!
        return (*(seekIndex(index))).data;
    }
    /*Returns an array of pointers to items from the specified indicies.*/
    T ** get(unsigned int index, unsigned int arrayLength){ //Tested
        T ** array = new T*[arrayLength];
        Linker * current = seekIndex(index);
        for(unsigned int i = 0; i < length; ++i){
            *(array + i) = (*current).data;
            current = (*current).next;
        }
    }
    /*Adds an item to the beginning of the array.*/
    void prepend(T * item){     //Tested!
        ppnd(item);
        ++length;
    }
    /*Adds an array of items to the beginning of the list*/
    void prepend(T * item, unsigned int arrayLength){   //Tested!
        T * temp = item + arrayLength;
        do{
            ppnd(--temp);
        }while(temp > item);
        length+=arrayLength;
    }
    /*Copies an item and adds it to the end of the list.*/
   //NOTE: You can't have an append that accepts an object, because as a template class, you have no way to copy it.
    /*Adds an item to the end of the list.*/
    void append(T * item){      //Tested!
        apnd(item);
        ++length;
    }
    /*Adds an array of items to the end of the list.*/
    void append(T * item, unsigned int arrayLength){    //Tested!
        T * terminal = item + arrayLength;
        do{
            apnd(item);
        }while(++item < terminal);
        length += arrayLength;
    }
     /*Inserts an item into the list at the specified index.  Moves <item> and everything in a higher index up by one.*/
    void insert(T * item, unsigned int index){  //Tested!
        Linker ** seek = getPointerToIndex(index);
        *seek = new Linker(item, *seek);
    }
    /*Takes an array of items, and inserts them all into the array. Moves <item> and everything in a higher index up by <numElements>.*/
    void insert(T * item, unsigned int index, unsigned int const &numElements){    //Tested!
        Linker ** nextPointer = getPointerToIndex(index);   //The first element in the array
        Linker * last = *nextPointer;                       //copies the data of the pointer (not the data it references)
        for(unsigned int i = 0; i < numElements; ++i){
            *nextPointer = new Linker(item + i);            //This sets the previous pointer (to the next obj) as well as defining the next object.
            nextPointer = &((**nextPointer).next);          //The pointer to the next object isn't yet known, so you need to set it afterwards.
        }
        (*nextPointer) = last;
        length += numElements;
    }
    /*NOTE:  The overloaded version of remove(T * item) was taken out because if the class <T> is an integer, it creates an ambiguous overload.*/
    /*Removes the item at the provided index from the list.*/
    void remove(unsigned int const &index){ //Tested!
        Linker * temp;
        if(index == 0){
            temp = (*foot).next;
            delete foot;
            foot = temp;
        }else{
            temp = seekIndex(index-1);
            Linker * skip = (*((*temp).next)).next;
            delete (*temp).next;
            (*temp).next = skip;
        }
        --length;
    }
    /*Removes a number of elements from the list.  The start index is included in the removal.*/
    void remove(unsigned int index, unsigned int arrayLength){  //Tested!
       length -= arrayLength;
       Linker ** start = getPointerToIndex(index);
       Linker * current = *start;
       Linker * prev;
       do{
            prev = current;
            current = current->next;
            delete prev;
       }while(--arrayLength);
       *start = current;
    }
    /*Removes and returns the last element in an array.*/
    T * dropLast(){                 //Tested!
        Linker * last = seekIndex(--length);
        T * dat =  last->data;
        delete last;
        return dat;
    }
    /*Removes and returns the first element in an array.*/
    T * dropFirst(){                //Tested!
        T * dat = foot->data;
        Linker * prev = foot;
        foot = foot->next;
        delete prev;
        --length;
        return dat;
    }
    /*Swaps the items at the two respective indices.*/
    void swap(unsigned int const &index0, unsigned int const &index1){  //Tested!
        T ** data1 = &((*(seekIndex(index0))).data);
        T ** data2 = &((*(seekIndex(index1))).data);
        /*The next sequence swaps the pointers to the two data.
        It uses no temp variable, is at least as efficient as using a temp, though probably more efficient.*/
        T * temp = *data1;
        *data1 = *data2;
        *data2 = temp;
    }
    void reverseIndicies(){ //Works!  Very well!
        Linker * next;
        Linker * current = foot;
        Linker * prev = 0;

        for(unsigned int i = 0; i < length; ++i){
            next = current->next;
            current->next = prev;
            prev = current;
            current = next;
        }
        foot = prev;
    }
    /*Goes through the entire linked list and deletes all data members stored inside.*/
    void deleteElements(){  //Untested
        Linker * current = foot;
        Linker * prev;
        ++length;
        while(--length){
            prev = current;
            current = (*current).next;
            delete (*prev).data;
            delete prev;
        }
    }
    /*Produces a copy of every element and returns the entire list as an array*/
    T * toArray(){              //Tested!
        T * array = new T[length];
        Linker * current = foot;
        for(unsigned int i = 0; i < length; ++i){
            array[i] = *(current->data);
            current = current->next;
        }
        return array;
    }
    /*The destructor for the list.  Does not clear the addresses pointed to.*/
    ~SinglyLinkedList(){    //untested
        Linker * prev;
        ++length;
        while(--length){
            prev = foot;
            foot = (*foot).next;
            delete prev;
        }
    }

    private:
    /*Returns the linker of the specified index.*/
    Linker * seekIndex(unsigned int index){         //Tested!  Everything relies on it, and they work.
        Linker * current = foot;
        for(unsigned int i = 0; i < index; ++i){
            current = current->next;
        }
        return current;
    }
    /*Gets a pointer to the pointer of an index.*/
    Linker ** getPointerToIndex(unsigned int index){    //Tested!  Everything relies on it, and they work.
        if(index == 0){
            return &foot;
        }
        Linker * current = foot;
        for(unsigned int i = 0; i < index-1; ++i){
            current = current->next;    //uses a regular pointer to avoid unnecessary dereferences.
        }
        return &(current->next);
    }
    /*An inline function that executes in both of the overloaded prepend methods.*/
    inline void ppnd(T*item){       //Tested /w prepend functions.
        Linker * tmp = new Linker(item, foot);
        foot = tmp;
    }
    /*An lineline function that executes in both of the overloaded append methods.*/
    inline void apnd(T*item){       //Tested /w append functions.
        *(getPointerToIndex(length)) = new Linker(item);
    }
};

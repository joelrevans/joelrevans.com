#ifndef INTEGER_H
#define INTEGER_H

class Integer{
    public:

    /*Returns the value of a bit from a binary number as either 0 or 1, with the least significant bit corresponding to index=0.*/
    inline static unsigned int getBit(unsigned int const &value, unsigned int const &index)
    {
        return (value >> index) & 1;
    }

    /*Rewrites the value of a bit from a binary number as a 1, with the least significant bit corresponding to index=0.*/
    inline static void setBitToOne(unsigned int &value, unsigned int const &index)
    {
        value |= 1 << index;
    }

    /*Rewrites the value of a bit from a binary number as a 1, with the least significant bit corresponding to index=0.*/
    inline static void setBitToZero(unsigned int &value, unsigned int const &index)
    {
        value &= ~(1 << index);
    }

    /*Clears n number of the most significant bits of the integer.*/
    inline static unsigned int clearMostSignificantBits(unsigned int const &value, unsigned int const &n)
    {
        return (value << n) >> n;
    }

    /*Clears n number of the least significant bits of the integer.*/
    inline static unsigned int clearLeastSignificantBits(unsigned int const &value, unsigned int const &n)
    {
        return (value >> n) << n;
    }
};
#endif

#include <math.h>
#include <stdlib.h>

using namespace std;

class Integer{
    public:
    inline static unsigned int getBit(unsigned int const &value, unsigned int const &index){
        return (value >> index) & 1;
    }
    inline static void setBitToOne(unsigned int &value, unsigned int const &index){
        value |= (1 << index);
    }
    inline static void setBitToZero(unsigned int &value, unsigned int const &index){
        value &= ~(1 << index);
    }
    /*For testing purposes only.*/
    static unsigned char * toCharArray(unsigned int const &value){
        unsigned char *c = new unsigned char[32+1];
        for(unsigned int i = 0; i < 32; i++){
            c[i] = getBit(value, 31 - i) | 48;
        }
        c[32] = 0;
        return c;
    }
    /*Clears n number of bits (to zero) on the left side (most significant bits) of the integer.
    A value of 32 is not accepted.*/
    inline static unsigned int clearLeft(unsigned int const &value, unsigned int const &n){  //Tested and passed!

        return (value << n) >> n;
    }
    /*Clears n number of bits (to zero) on the left side (most significant bits) of the integer.
    A value of 32 is not accepted.*/
    inline static unsigned int clearRight(unsigned int const &value, unsigned int const &n){ //Tested and passed!
        return (value >> n) << n;
    }
};

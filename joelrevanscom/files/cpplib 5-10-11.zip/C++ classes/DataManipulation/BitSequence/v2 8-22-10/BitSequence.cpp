//  Required classes
#include "Integer.cpp"
#include <iostream>
#include "LinkedList.cpp"
#include <stdlib.h::malloc>     //For MALLOC

class BitSequence{

    private:
    unsigned int length;
    unsigned int * data;

    public:
    /*Constructor Function for the BitSequence object.  Note:  Sequence is not initialized to zero.
    @param length Length of the sequence in bits.*/
    BitSequence(unsigned int const &arrayLength){
        data = static_cast<unsigned int*>(malloc(bitLengthToIntLength(arrayLength) * sizeof(unsigned int)));    //Has to be converted from bits to ints
        length = arrayLength;
    }
    /*  Will turn the provided array object into a sequence of bits.
        NOTE:   The original data may be edited by the sequence object.  No copy operation is performed.
        @param array A pointer to the integer array which will be referenced.
        @param lengthInIntegers The length of the array, in number of integers.*/
    BitSequence(unsigned int * const array, unsigned int const &bitLength){
        data = array;
        length = bitLength;
    }
    /*Constructor Function for the BitSequence object
    @param array A pointer to an integer array that will be copied.
    @param arrayLength The length of the provided integer array, in *bits*.
    @param offset   This will shift the array to the left by this number of bits.  Providing any value for offset
                    will automatically cause the function to copy the array rather than simply referencing it.*/
    BitSequence(unsigned int * array, unsigned int const &bitLength, unsigned int const &offset){   //TESTED Thoroughly.
        length = bitLength+offset;
        unsigned int const intLength = bitLengthToIntLength(length);
        data = static_cast<unsigned int*>(malloc(intLength * sizeof(unsigned int)));

        unsigned int const * end = array + intLength-1; //-1 for length
        unsigned int *i = data - 1;
        --array;
        do{
            *(++i) = *(++array);
        }while(array < end);
        shiftLeft(offset);
        shrink(offset);
    }
    /*The destructor for the sequence object.  Will free any data referenced by the sequence as well.*/
    ~BitSequence(){
        free(data);
    }

    /*Returns the length of the sequence in bits.*/
    inline unsigned int lengthBits() const {return length;}
    /*Returns the length of the sequence in bytes.*/
    inline unsigned int lengthBytes() const {return bitLengthToByteLength(length);}
    /*Returns the length of the sequence in Ints.*/
    inline unsigned int lengthInts() const {return bitLengthToIntLength(length);}

    /*Sets the value of a specified bit to a one.
    @param index The index location of the particular bit, originating from the left.*/
    void setBitToOne(const unsigned int &index){
        Integer::setBitToOne(*(data + (index >> 5)), index & 0x1F);
    }
    /*Sets the value of a specified bit to a zero.
    @param index The index location of the particular bit, originating from the left.*/
    void setBitToZero(unsigned int const &index){
        Integer::setBitToZero(*(data + (index >> 5)), index & 0x1F);
    }
    /*Returns the value of a particular bit.
    @param index The index location of the particular bit, originating from the left.*/
    unsigned int getBit(unsigned int const &index){
        //The below result used to be 31 - (index & 0x0000001F)), but the one's complement is equivalent.
        return Integer::getBit(*(data + (index >> 5)), ~index & 0x1F);  //~ has higher precedence than &, so no parenthesees needed.
    }
    /*Returns a new sequence containing the data in the specified segment.*/
    BitSequence * getBits(unsigned int const &start, unsigned int const &bitLength){    //Tested thoroughly, and passed.
        return new BitSequence(data + (start >> 5), bitLength, start & 0x1F);
    }
    /*Replaces a sequence of bits with the specified sequence.*/
    void setBits(unsigned int const &start, BitSequence * const fillBits){        //TESTED AND PASSED
        BitSequence s = *((*fillBits).clone());
        //Aligns the array.
        s.expand(start & 0x1F);
        s.shiftRight(start & 0x1F);
        //s.fillZero(0, start & 0x1F);      //Fillzero isnt needed, because a right-shift less than 32 should fill zeroes.

        //Clears the host array for replacement
        fillZero(start, (*fillBits).lengthBits());
        unsigned int * fill = s.toInt();
        unsigned int * host = data + (start >> 5);
        unsigned int endPlus = bitLengthToIntLength(s.lengthBits());
        for(unsigned int i = 0; i < endPlus;i++){
            *host |= *fill;
            fill++;
            host++;
        }
        delete &s;
    }
    /*Shifts the sequence to the left by <offset> number of bits.  Does not clear the rightmost values to zero after shifting.*/
    void shiftLeft(unsigned int offset){    //Tested Thoroughly.  Works.
        unsigned int const lookAhead = offset >> 5;
        unsigned int * lastOne = data + bitLengthToIntLength(length) - lookAhead;
        unsigned int * iPlusLookAhead = lookAhead + data;
        offset &= 0x1F;
        unsigned int * i = data;
           if(offset){
               unsigned int const thirtyTwoMinusOffset = 32 - offset;
               for(i; i < lastOne-1; ++i){
                   *i = *(iPlusLookAhead) << offset;
                   *i |= *(++iPlusLookAhead) >> thirtyTwoMinusOffset;
                   //*i = (*(iPlusLookAhead) << offset) | *(iPlusLookAhead+1) >> (thirtyTwoMinusOffset);++iPlusLookAhead;
               }
               //*i = (*(iPlusLookAhead) << offset);
           }
           //This used to be in an !offset if statement, but the last element needs this regardless, so it will run once.
           --iPlusLookAhead;    //Has to start off one less because of the next prefix operator.
           for(i; i < lastOne; ++i){    //If offset is zero, this runs all the way through.  Otherwise, it only runs once, on the last term.
               *i = (*(++iPlusLookAhead) << offset);
           }
    }
    /*Shifts the sequence to the right by <offset> number of bits.  Does not clear the leftmost values to zero after shifting.*/
    void shiftRight(unsigned int offset){   //Tested with many shifts.  Had some trouble, but it was easy to fix (missing-1 on first line).  Too easy...
        unsigned int * i = data + bitLengthToIntLength(length)-1;
        unsigned int const lookBack = offset>>5;
        offset &=0x1F;
        unsigned int * iMinusLookBack = i - lookBack;
        unsigned int const * dataPlusLookBack = data + lookBack;
        if(offset){
            unsigned int const thirtyTwoMinusOffset = 32 - offset;
            for(i; i > data + lookBack; --i){
                *i = (*(iMinusLookBack) >> offset);
                *i |= *(--iMinusLookBack)<<(thirtyTwoMinusOffset);
            }
        }
        ++iMinusLookBack;   //Added here because of the -- prefix
        for(i; i >= dataPlusLookBack; --i){ //Shifts across whole-integer gaps.
            *i = *(--iMinusLookBack) >> offset;
        }
    }
    /*Increases the size of the sequence from the right side by <offset> number of bits.  Expanded values are not cleared.*/
    void expand(unsigned int const &offset){   //Tested.  Works.
        length+= offset;
        data = static_cast<unsigned int*>(realloc(data, bitLengthToIntLength(length) * sizeof(unsigned int)));    //Realloc will not move the pointer if the size requested is the same.
    }
    /*Decraeses the size of the sequence by <offset> number of bits.  Data is removed from the right side.*/
    void shrink(unsigned int const &offset){    //Tested.  Also works.
        length-=offset;
        data = static_cast<unsigned int*>(realloc(data, bitLengthToIntLength(length)*sizeof(unsigned int)));
    }
    /*Inserts a series of bits at the specified index position.
    @param index Inserts the sequence before this index, pushing all bits past and at the index forward.*/
    void insertBits(BitSequence * insert, unsigned int const &index){   //Tested thoroughly, and passed!
        if(index == length){    //Handles the event if the index is the length of the sequence.
            expand((*insert).lengthBits());         //I feel that this should somehow be handled more elegantly.
            setBits(length - (*insert).lengthBits(), insert);
            return;
        }   //Else {
        BitSequence *secondHalf = split(index);
        expand((*insert).lengthBits());
		setBits(length - (*insert).lengthBits(), insert);
        merge(secondHalf);
        delete secondHalf;
    }
    /*Removes bits from the specified indicies.  Includes the specified index.*/
    void removeBits(unsigned int const &index, unsigned int const &length){ //Tested and tried.
        BitSequence * secondHalf = split(index);
        (*secondHalf).shiftLeft(length);
        (*secondHalf).shrink(length);
        merge(secondHalf);
        delete secondHalf;
    }
    /*Fills a sequence of bits with zeroes.*/
    void fillZero(unsigned int const &start, unsigned int const &bitLength){   //This method has been tested rigorously.  It works.
        if((start&0x1F) + bitLength > 32){ //if the area to fill spans across more than one integer.
            *(data + (start >> 5)) &= (start & 0x1F) ? 0xFFFFFFFE << (31 - (start&0x1F)) : 0;
            for(unsigned int * i = data + (start >> 5) + 1; i < data + ((start + bitLength - 1)>>5); i++){  //1 is subtracted because bitLength isnt zeroed
                *i = 0;
            }
            *(data + ((start + bitLength-1)>>5)) &= ((start+bitLength) & 0x1F) ? 0xFFFFFFFF >> ((start + bitLength) & 0x1F) : 0;
        }else{                          //If start + bitLength is equal to thirty two
            *(data + (start >> 5)) &= ((start & 0x1F) == 0 && bitLength == 32) ? 0 : ~(((1 << bitLength) - 1) << (32 - start - bitLength));
        }
    }

    /*Fills a sequence of bits with ones.*/
    void fillOne(unsigned int const &start, unsigned int const &bitLength){ //Tested thoroughly against fillZero.
        if((start&0x1F) + bitLength > 32){ //if the area to fill spans across more than one integer.
            *(data + (start >> 5)) |= (start & 0x1F) ? ~(0xFFFFFFFE << (31 - (start&0x1F))) : 0xFFFFFFFF;
            for(unsigned int * i = data + (start >> 5) + 1; i < data + ((start + bitLength - 1)>>5); i++){  //1 is subtracted because bitLength isnt zeroed
                *i = 0xFFFFFFFF;
            }
            *(data + ((start + bitLength-1)>>5)) |= ((start+bitLength) & 0x1F) ? ~(0xFFFFFFFF >> ((start + bitLength) & 0x1F)) : 0xFFFFFFFF;
        }else{                          //If start + bitLength is equal to thirty two
            *(data + (start >> 5)) |= ((start & 0x1F) == 0 && bitLength == 32) ? 0xFFFFFFFF : ((1 << bitLength) - 1) << (32 - start - bitLength);
        }
    }
    /*  Returns a pointer to the a copy of the sequence data which has had each bit converted to a character.
        This function is only practical for test purposes.*/
    unsigned char * const toCharArray(){            //Tested extremely thoroughly
        unsigned char * ars = new unsigned char[length+1];
        unsigned int i = length-1;
        do{
            ars[i] = getBit(i) + 48;    //Ascii for zero is 48
        }while(i--);    //For some reason, screws up if you use the prefix--;
        ars[length] = 0;
        return ars;
    }
    /*The sequence provided will be attached to the end of this sequence, effectively combining the two.
    The provided sequence will not be overwritten or modified.*/
    void merge(BitSequence * const s){      //Tested lightly but thoughtfully, and I'm quite sure it works.
        unsigned int len = length;
        expand((*s).lengthBits());
        setBits(len, s);
    }
    /*Splits the sequence into two parts, returning the second.
    @param start The index at which to begin division.  This index is included in the second half of the sequence.*/
    BitSequence * split(unsigned int const &start){     //Tested Thorougly.
        //Zero not accepted!  Still wondering if I should set an exception for this.
        BitSequence *s = getBits(start, length - start);
        shrink(length - start);
        return s;
    }

    bool equals(BitSequence * s){   //Tested, approved.
        if((*s).lengthBits() != length){    //Im debating whether this should be added or not...
            return false;
        }
        unsigned int * const end = data + bitLengthToIntLength(length)-1;
        unsigned int * host = data;
        unsigned int * client = (*s).toInt();
        while(host < end){
            if(*host != *client){
                return false;
            }
            ++host;
            ++client;
        }
        return Integer::clearRight(*host, (32 - (length & 0x1F))) == Integer::clearRight(*client, (32 - (length & 0x1F)));    //compares the last bit.
    }

    /*Returns a pointer to the sequence data as represented in an array of unsigned integers.*/
    inline unsigned int * const toInt(){    //Tested!
        return data;
    }

    /*Returns a sequence of bits, and interprets it as though it were an integer.  The <length> parameter may be at most <sizeof(unsigned int)>.*/
    unsigned int readAsInteger(unsigned int const &start, unsigned int const &length){  //Tested thoroughly!
        BitSequence * temp = getBits(start, length);
        temp->shiftRight(32 - length);
        unsigned int returnValue = *(temp->toInt());
        delete temp;
        return returnValue;
    }

    //void shiftBits(unsigned int changePosition, bool direction,
    /*Searches the array for the specified bit sequence, and returns an ordered list of the index locations for matching data.
      The provided <&getLength> parameter will be changed to reflect the length of the array output.
      The returned list's elements will be in descending order (for optimization).*/
    unsigned int * linearSearch(BitSequence * key, unsigned int &getLength){        //IT LIIIIIVES!!!
        SinglyLinkedList<unsigned int> indices = *(new SinglyLinkedList<unsigned int>());
        unsigned int const len = key->lengthBits(); //Optimization variable
        unsigned int const end = length - len + 1;     //Optimization variable
        BitSequence * temp;
        for(unsigned int i = 0; i < end; ++i){
            temp = getBits(i, len);
            if(key->equals(temp)){
                indices.prepend(new unsigned int(i));
            }
            delete temp;
        }
        getLength = indices.getLength();
        unsigned int * returnValue = indices.toArray();
        indices.deleteElements();
        delete &indices;
        return returnValue;
    }

    /*Searches the array for the specified bit sequence, and returns all of the index locations for matching data.
    The [0] index contains the length of the array.
    This method is significantly faster than linearSearch, but requires approximately 7 times the memory.*/
    /*unsigned int parallelSearch(BitSequence key){}*/
    /*Creates an instance identical to this sequence object.*/
    inline BitSequence * clone(){           //Tested
        return new BitSequence(data, length, 0);
    }

    template <class T>
    BitSequence * convertToSequence(T * ptr){
        return new BitSequence(reinterpret_cast<unsigned int *>(ptr), bitLengthToIntLength(sizeof(T)<<3), 0);   //could be opped a little
    }

    private:
    /*Given a length value in bits, returns the number of ints needed to store the data.*/
    inline unsigned int bitLengthToIntLength(unsigned int const &numBits) const{
        return (numBits >> 5) + (numBits & 0x1F ? 1:0);    //Has to be converted from bits to ints
    }
    inline unsigned int bitLengthToByteLength(unsigned int const &numBits) const{
        return (length >> 3) + (numBits & 7 ? 1:0);
    }
};

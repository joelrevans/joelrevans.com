#ifndef BITSEQUENCE_H
#define BITSEQUENCE_H

#include "Integer.h"
#include <iostream>
#include "SinglyLinkedList.cpp"
#include <stdlib.h>


class BitSequence{

    public:

    /*  Constructor Function for the BitSequence object.  Note:  Sequence is not initialized to zero.
        @param length Length of the sequence in bits.*/
    BitSequence(unsigned int const &arrayLength);

    /*  Constructor Function for the BitSequence object
        @param array A pointer to an integer array that will be copied.
        @param arrayLength The length of the provided integer array, in *bits*.
        @param offset   This will shift the array to the left by this number of bits.*/
    BitSequence(unsigned int * array, unsigned int const &bitLength, unsigned int const &offset);

    /*The destructor for the sequence object.  Will free any data referenced by the sequence as well.*/
    ~BitSequence();

    /*Returns the length of the sequence in bits.*/
    inline unsigned int lengthBits() const;

    /*Returns the length of the sequence in bytes.*/
    inline unsigned int lengthBytes() const;

    /*Returns the length of the sequence in Ints.*/
    inline unsigned int lengthInts() const;

    /*  Sets the value of a specified bit to a one.
        @param index The index location of the particular bit, originating from the left.*/
    void setBitToOne(const unsigned int &index);

    /*  Sets the value of a specified bit to a zero.
        @param index The index location of the particular bit, originating from the left.*/
    void setBitToZero(unsigned int const &index);

    /*  Returns the value of a particular bit.
        @param index The index location of the particular bit, originating from the left.*/
    unsigned int getBit(unsigned int const &index);

    /*  Returns a new sequence containing the data in the specified segment.*/
    BitSequence * getBits(unsigned int const &start, unsigned int const &bitLength);

    /*  Replaces a sequence of bits with the specified sequence.*/
    void setBits(unsigned int const &start, BitSequence * const fillBits);

    /*  Shifts the sequence to the left by <offset> number of bits.  Does not clear the rightmost values to zero after shifting.*/
    void shiftLeft(unsigned int offset);

    /*  Shifts the sequence to the right by <offset> number of bits.  Does not clear the leftmost values to zero after shifting.*/
    void shiftRight(unsigned int offset);

    /*  Increases the size of the sequence from the right side by <offset> number of bits.  Expanded values are not cleared.*/
    void expand(unsigned int const &offset);

    /*  Decraeses the size of the sequence by <offset> number of bits.  Data is removed from the right side.*/
    void shrink(unsigned int const &offset);

    /*  Inserts a series of bits at the specified index position.
        @param index Inserts the sequence before this index, pushing all bits past and at the index forward.*/
    void insertBits(BitSequence * insert, unsigned int const &index);

    /*  Removes bits from the specified indicies.  Includes the specified index.*/
   void removeBits(unsigned int const &index, unsigned int const &length);

    /*  Fills a sequence of bits with zeroes.*/
    void fillZero(unsigned int const &start, unsigned int const &bitLength);

    /*  Fills a sequence of bits with ones.*/
    void fillOne(unsigned int const &start, unsigned int const &bitLength);

    /*  Returns a pointer to the a copy of the sequence data which has had each bit converted to a character.
        This function is only practical for test purposes.*/
    unsigned char * const toCharArray();

    /*  The sequence provided will be attached to the end of this sequence, effectively combining the two.
        The provided sequence will not be overwritten or modified.*/
    void merge(BitSequence * const s);

    /*  Splits the sequence into two parts, returning the second.
        @param start The index at which to begin division.  This index is included in the second half of the sequence.*/
    BitSequence * split(unsigned int const &start);

    bool equals(BitSequence * s);

    /*  Returns a pointer to the sequence data as represented in an array of unsigned integers.*/
    inline unsigned int * const toInt();

    /*  Returns a sequence of bits, and interprets it as though it were an integer.  The <length> parameter may be at most <sizeof(unsigned int)>.*/
    unsigned int readAsInteger(unsigned int const &start, unsigned int const &length);

    /*  Searches the array for the specified bit sequence, and returns an ordered list of the index locations for matching data.
        The provided <&getLength> parameter will be changed to reflect the length of the array output.
        The returned list's elements will be in descending order (for optimization).*/
    unsigned int * linearSearch(BitSequence * key, unsigned int &getLength);

    /*Creates an instance identical to this sequence object.*/
    inline BitSequence * clone();

    template <class T>
    BitSequence * convertToSequence(T * ptr);

    private:

    /*Given a length value in bits, returns the number of ints needed to store the data.*/
    inline unsigned int bitLengthToIntLength(unsigned int const &numBits) const{
        return (numBits >> 5) + (numBits & 0x1F ? 1:0);    //Has to be converted from bits to ints
    }

    inline unsigned int bitLengthToByteLength(unsigned int const &numBits) const{
        return (length >> 3) + (numBits & 7 ? 1:0);
    }

    unsigned int length;
    unsigned int * data;

};

#endif

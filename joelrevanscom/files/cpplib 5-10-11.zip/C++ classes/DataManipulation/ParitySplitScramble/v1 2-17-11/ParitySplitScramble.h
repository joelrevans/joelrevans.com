#ifndef PARITYSPLITSCRAMBLE_H
#define PARITYSPLITSCRAMBLE_H

#include "BitSequence.cpp"

/*
NOTE:   This algorithm repeats much faster--ln(length)*2--for powers of two--2^n.
*/

/*This class scrambles data by placing the even bits in a sequence in order, followed by the odd bits.*/
class ParitySplitScramble{

    public:

    /*Encodes the data provided and returns a scrambled BitSequence object.*/
    static BitSequence * encode(BitSequence &input){    //TESTED

        unsigned int const inLength = input.lengthBits();

        BitSequence * output = new BitSequence(inLength);

        unsigned int posOut = 0xFFFFFFFF;


        for(unsigned int a = 0; a < inLength; a+=2)
            input.getBit(a) ? (*output).setBitToOne(++posOut) : (*output).setBitToZero(++posOut);
        for(unsigned int a = 1; a < inLength; a+=2)
            input.getBit(a) ? (*output).setBitToOne(++posOut) : (*output).setBitToZero(++posOut);

        return output;

    }

    /*Dencodes the data provided and returns an unscrambled BitSequence object.*/
    static BitSequence * decode(BitSequence &input){    //TESTED

        unsigned int const inlen = input.lengthBits();
        unsigned int const opvar = inlen/2;

        BitSequence * output = new BitSequence(inlen);


        unsigned int i = 0xFFFFFFFF;
        while(++i < opvar)
            input.getBit(i) ? (*output).setBitToOne(i<<1) : (*output).setBitToZero(i<<1);
        --i;
        while(++i < inlen)
            input.getBit(i) ? (*output).setBitToOne(((i-opvar)*2)+1) : (*output).setBitToZero(((i-opvar)*2)+1);

        return output;
    }
};

#endif

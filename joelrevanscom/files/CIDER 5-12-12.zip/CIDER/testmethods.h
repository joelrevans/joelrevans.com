#include <dos.h>
#include <iostream>
#include "BitSequence.h"

using namespace std;
using namespace Juice;


void TestEndianness(){
	unsigned int * test = new unsigned int();
    cout << hex << *test << endl;
    unsigned char * test2;
    test2 = (unsigned char*)test;
    *test2 = 0xCF;
    cout << hex << (unsigned int) *test2 << endl;
    cout << hex << *test << endl;

    *test |= 0x00100000;
    cout << "Test2+0:  " << hex << (unsigned int) *(test2+0) << endl;
    cout << "Test2+1:  "<< hex << (unsigned int) *(test2+1) << endl;
    cout << "Test2+2:  "<< hex << (unsigned int) *(test2+2) << endl;
    cout << "Test2+3:  "<< hex << (unsigned int) *(test2+3) << endl;
    cout << "Test2+0:  " << hex << *test << endl;

    *test2 = 0xFF;
    *test2>>=2;
    cout << hex << (unsigned int) *test2 << endl;
    cout << hex << *test << endl;

    *test2 = 0xFC;
    *(test2+1) = 0x3;
    *test>>=2;
    cout << hex << (unsigned int) *test2 << endl;
    cout << hex << *test << endl;
}

void TestBitSequence(){	//Tests the second constructor
	unsigned long long int a[4] = {0xF0F0F0F0F0F0F0F0ULL,0xF0F0F0F0F0F0F0F0ULL,0xF0F0F0F0F0F0F0F0ULL,0xF0F0F0F0F0F0F0F0ULL};
	cout << hex << a[0] << endl;
    {
		BitSequence b(a, 0, 0);
		cout << b.ToCharArray() << endl;
    }
    {
		BitSequence b(a, 0, 24);
		cout << b.ToCharArray() << endl;
    }
    {
		BitSequence b(a, 0, 63);
		cout << b.ToCharArray() << endl;
    }
    {
		BitSequence b(a, 0, 64);
		cout << b.ToCharArray() << endl;
    }
    {
		BitSequence b(a, 0, 65);
		cout << b.ToCharArray() << endl;
    }
    {
		BitSequence b(a, 0, 127);
		cout << b.ToCharArray() << endl;
    }
    {
		BitSequence b(a, 0, 128);
		cout << b.ToCharArray() << endl;
    }
    {
		BitSequence b(a, 0, 129);
		cout << b.ToCharArray() << endl;
    }
    //Starts testing the second constructor here.
    {
		BitSequence b(a, 0);
		cout << b.ToCharArray() << endl;
    }
    {
		BitSequence b(a, 24);
		cout << b.ToCharArray() << endl;
    }
    {
		BitSequence b(a, 63);
		cout << b.ToCharArray() << endl;
    }
    {
		BitSequence b(a, 64);
		cout << b.ToCharArray() << endl;
    }
    {
		BitSequence b(a, 65);
		cout << b.ToCharArray() << endl;
    }
    {
		BitSequence b(a, 127);
		cout << b.ToCharArray() << endl;
    }
    {
		BitSequence b(a, 128);
		cout << b.ToCharArray() << endl;
    }
    {
		BitSequence b(a, 129);
		cout << b.ToCharArray() << endl;
    }
}

void TestRead(){    //single bit
    unsigned long long int a[4] = {0xF0F0F0F0F0F0F0F0ULL,0xF0F0F0F0F0F0F0F0ULL,0xF0F0F0F0F0F0F0F0ULL,0xF0F0F0F0F0F0F0F0ULL};
	cout << hex << a[0] << endl;

    unsigned int length = 129;

    BitSequence c(a, 0, length);
    for(unsigned int i = 0; i < length; ++i){
        cout << c.Read(i);
    }
    cout << endl;
}

void TestSetClear(){  //Aight
    unsigned long long int a[4] = {0ULL, 0ULL, 0ULL, 0ULL};

	unsigned int blen = 3000;
    BitSequence b(a, 0, blen);

    for(unsigned int i = 0; i < blen; i+=2)
        b.Set(i);
    cout << b.ToCharArray() << endl << endl;

    for(unsigned int i = 1; i < blen; i+=2)
        b.Set(i);
    cout << b.ToCharArray() << endl << endl;

    for(unsigned int i = 0; i < blen; i+=2)
        b.Clear(i);
    cout << b.ToCharArray() << endl << endl;

    for(unsigned int i = 1; i < blen; i+=2)
        b.Clear(i);
    cout << b.ToCharArray() << endl << endl;

}

void TestShiftUp(){
    unsigned long long int a[4] = {0x0F0F0F0F0F0F0F0FULL,0x0F0F0F0F0F0F0F0FULL,0x0F0F0F0F0F0F0F0FULL,0x0F0F0F0F0F0F0F0FULL};

    for(int i = 11; i < 12; ++i)
	{
        BitSequence b(a, 0, 129);
        b.ShiftUp(i);
        cout << b.ToCharArray() << endl;
    }
    {
        BitSequence b(a, 0, 129);
        b.ShiftUp(63);
        cout << b.ToCharArray() << endl;
    }
    {
        BitSequence b(a, 0, 129);
        b.ShiftUp(64);
        cout << b.ToCharArray() << endl;
    }
    {
        BitSequence b(a, 0, 129);
        b.ShiftUp(65);
        cout << b.ToCharArray() << endl;
    }
    {
        BitSequence b(a, 0, 256);
        b.ShiftUp(127);
        cout << b.ToCharArray() << endl;
    }
    {
        BitSequence b(a, 0, 256);
        b.ShiftUp(128);
        cout << b.ToCharArray() << endl;
    }
    {
        BitSequence b(a, 0, 256);
        b.ShiftUp(129);
        cout << b.ToCharArray() << endl;
    }
}

void TestShiftDown(){
    unsigned long long int a[4] = {0x0F0F0F0F0F0F0F0FULL,0x0F0F0F0F0F0F0F0FULL,0x0F0F0F0F0F0F0F0FULL,0x0F0F0F0F0F0F0F0FULL};
    for(unsigned int i = 0; i < 129; ++i)
        cout << (i%10)?'1':'0';
	cout << endl;
	for(int i = 0; i < 12; ++i)
    {
        BitSequence b(a, 0, 129);
        b.ShiftDown(i);
        cout << b.ToCharArray() << endl;
    }

    {
        BitSequence b(a, 0, 129);
        b.ShiftDown(63);
        cout << b.ToCharArray() << endl;
    }
    {
        BitSequence b(a, 0, 129);
        b.ShiftDown(64);
        cout << b.ToCharArray() << endl;
    }
    {
        BitSequence b(a, 0, 129);
        b.ShiftDown(65);
        cout << b.ToCharArray() << endl;
    }
    {
        BitSequence b(a, 0, 256);
        b.ShiftDown(127);
        cout << b.ToCharArray() << endl;
    }
    {
        BitSequence b(a, 0, 256);
        b.ShiftDown(128);
        cout << b.ToCharArray() << endl;
    }
    {
        BitSequence b(a, 0, 256);
        b.ShiftDown(129);
        cout << b.ToCharArray() << endl;
    }
}

void TestSet(){
	unsigned long long int a[4] = {0ULL, 0ULL, 0ULL, 0ULL};

	for(int i = 0; i < 256; i+=8){
		BitSequence b(a, 0, 255);
		b.Set(i, 256-i);
		cout << b.ToCharArray() << endl;
    }
    for(int i = 0; i < 256; i+=8){
		BitSequence b(a, 0, 255);
		b.Set(0, i);
		cout << b.ToCharArray() << endl;
    }
}

void TestClear(){
	unsigned long long int a[4] = {0xFFFFFFFFFFFFFFFFULL, 0xFFFFFFFFFFFFFFFFULL, 0xFFFFFFFFFFFFFFFFULL, 0xFFFFFFFFFFFFFFFFULL};

	for(int i = 0; i < 256; i+=8){
		BitSequence b(a, 0, 255);
		b.Clear(i, 256-i);
		cout << b.ToCharArray() << endl;
    }
    for(int i = 0; i < 256; i+=8){
		BitSequence b(a, 0, 255);
		b.Clear(0, i);
		cout << b.ToCharArray() << endl;
    }
}

void TestRead2(){    //Multiple bits.
    unsigned long long int a[4] = {0x3030303030303030ULL,0x3030303030303030ULL,0x3030303030303030ULL,0x3030303030303030ULL};
    //unsigned long long int a[4] = {0xFFFFFFFFFFFFFFFFULL,0xFFFFFFFFFFFFFFFFULL,0xFFFFFFFFFFFFFFFFULL,0xFFFFFFFFFFFFFFFFULL};

    BitSequence b(a, 0, 256);
    for(int i = 0; i < 256; i+=25){
		cout << b.Read(0, i).ToCharArray() << endl;
    }
    for(int i = 0; i < 11; i++){
		cout << b.Read(0, i).ToCharArray() << endl;
    }
	for(int i = 0; i < 10; i++){
		cout << b.Read(i, 20).ToCharArray() << endl;
    }
	for(int i = 0; i < 30; i++){
		cout << b.Read(i, i).ToCharArray() << endl;
    }
}

void TestWrite(){
    unsigned long long int a[4] = {0ULL, 0ULL, 0ULL, 0ULL};
    //unsigned long long int a[4] = {0x3030303030303030ULL,0x3030303030303030ULL,0x3030303030303030ULL,0x3030303030303030ULL};
    unsigned long long int c[4] = {-1ULL, -1ULL, -1ULL, -1ULL};

	cout << BitSequence(a, 192).ToCharArray() << endl;
	cout << BitSequence(c, 126).ToCharArray() << endl;

    for(int i = 0; i+126 < 192; i+=4){
        BitSequence b(a, 192);
        BitSequence d(c, 126);
        b.Write(i, d);
        cout << b.ToCharArray() << endl;
    }
}

void TestSplitMerge(){
	char source[] = {'T', 'H','I','S',' ','I','S',' ','A',' ','S','T','I','C','K','U','P',};
	BitSequence b(source, 80);
	ArrayList<unsigned long long int> c(10);
	c[0] = 0; c[1] = 8; c[2] = 16; c[3] = 24; c[4] = 32; c[5] = 40; c[6] = 48; c[7] = 56; c[8] = 64; c[9] = 72;
	ArrayList<BitSequence> d = b.Split(c);
	for(unsigned long long int i = 0; i < d.Length(); ++i)
		//cout << d[i].ToCharArray() << endl;
		cout << d[i].ToObject<char>(0) << endl;

	cout << BitSequence::Merge(d).ToArray<char>() << endl;
}

void TestReplaceRemove(){
	//Replace
	char source[] = {'T','H','I','S',' ','I','S',' ','A',' ','S','T','I','C','K','U','X'};
	BitSequence b(source, 128);
	ArrayList<unsigned long long int> c(8);
	c[0] = 0; c[1] = 16; c[2] = 32; c[3] = 48; c[4] = 64; c[5] = 80; c[6] = 96; c[7] = 112;
	BitSequence d(source+16, 8);
	b.Replace(c, 8, d);
	cout << b.ToArray<char>() << endl;
	//Remove
	b = BitSequence(source, 128);
	b.Remove(c, 8);
	cout << b.ToArray<char>() << endl;
}
#ifndef	BITPATTERNTREE_CPP
#define	BITPATTERNTREE_CPP

#include "BitSequence.h"
#include "MutableList.h"
#include "ArrayList.h"
#include "SinglyLinkedList.h"
#include <limits.h>

namespace Juice{

	class BitPatternTree{
	private:

		class Branch{
			public:
				Branch * branch0;
				Branch * branch1;
				ArrayList<unsigned long long int> index;				//Doesn't have to be singly.  Can be any MutableList.
				
				Branch *& operator[](bool select){
					return select ? branch1 : branch0;
				}
		};

		/*The source sequence.*/
		BitSequence source;
		Branch * root;

	public:

		BitPatternTree(BitSequence& src){
			source = src;
			root = new Branch();
			root->index.Length(source.Length());

			for(unsigned long long int i = 0ULL; i < source.Length(); ++i)	//Populates the root (with all possibilities for empty search terms)
				root->index[i] = i;

			SinglyLinkedList<Branch*> branches;
			SinglyLinkedList<Branch*> buds;

			buds+=root;

			unsigned long long int depth = 0ULL;
 			while(buds.Length()){
				branches = buds;
				buds = SinglyLinkedList<Branch*>();
				while(branches.Length()){
					Branch& current = *(--branches);				//The branch currently being operated on
					
					current.branch0 = new Branch();					//Create two new buds.
					current.branch1 = new Branch();

					ArrayList<unsigned long long int>& index0 = current.branch0->index;
					ArrayList<unsigned long long int>& index1 = current.branch1->index;
					index0.Length(current.index.Length());
					index1.Length(current.index.Length());
					unsigned long long int i0 = 0ULL;	//counter for index0
					unsigned long long int i1 = 0ULL;	//counter for index1

					unsigned long long int lastIndex = current.index.Length()-1;	//opvar
					for(unsigned long long int j = 0ULL; j < lastIndex; ++j){			//Splits all of the index locations from the current branch and feeds it into the repspective buds.
						if(source.Read(current.index[j]+depth))
							index1[i1++] = current.index[j];
						else
							index0[i0++] = current.index[j];
					}
					
					if(current.index[lastIndex]+depth < source.Length()){	//This condition only needs to be run on the last item in the list.
						if(source.Read(current.index[lastIndex]+depth))
							index1[i1++] = current.index[lastIndex];
						else
							index0[i0++] = current.index[lastIndex];
					}

					index0.Length(i0);
					index1.Length(i1);

					if(i0>1)
						buds.Prepend(current.branch0);
					if(i1>1)
						buds.Prepend(current.branch1);
				}
				++depth;
			}
		}
		
		ArrayList<unsigned long long int> Search(BitSequence key){						//Done
			Branch * current = root;

			for(unsigned long long int i = 0ULL; i < key.Length(); ++i){
				if(current->index.Length()<2){							//Branches end when only one or zero buds occur.
					if(current->index.Length()){						//If current.index==1
						if(source.Read(current->index[0], key.Length())==key)
							break;										//Break and return this list
						else
							return ArrayList<unsigned long long int>(0);						//Empty list
					}else												//If current.index==0
						return ArrayList<unsigned long long int>(0);							//Empty list
				}
				current = (*current)[key.Read(i)];
			}
			return current->index;
		}

		BitSequence GetGreatestAreaKey(){
			BitSequence greatestTerm;
			unsigned long long int greatestArea = 0;
			unsigned long long int depth = 0ULL;

			SinglyLinkedList<Branch*> branches;
			branches += root;

			while(branches.Length()){
				SinglyLinkedList<Branch*> buds;
				while(branches.Length()){
					Branch& current = *(--branches);
					unsigned long long int size = current.index.Length() * depth;
					if(size > greatestArea){
						greatestArea = size;
						greatestTerm = source.Read(current.index[0], depth);
					}
					if(current.index.Length() > 2){
						buds += current.branch0;
						buds += current.branch1;
					}
				}
				branches = buds;
				depth++;
			}
			return greatestTerm;
		}

		BitSequence GetBestCIDERKey(){
			BitSequence greatestTerm;
			int greatestArea = LLONG_MIN;
			unsigned long long int depth = 0ULL;

			SinglyLinkedList<Branch*> branches;
			branches += root;

			while(branches.Length()){
				SinglyLinkedList<Branch*> buds;
				while(branches.Length()){
					Branch& current = *(--branches);
					
					int size = current.index.Length() * depth;
					unsigned long long int currentPos = current.index.Length();
					for(unsigned long long int i = 0ULL; i < current.index.Length(); ++i){
						size -= Integer::BinaryLog(currentPos);		//CIDER specific compression
						currentPos -= current.index[i];
					}

					if(size > greatestArea){
						greatestArea = size;
						greatestTerm = source.Read(current.index[0], depth);
					}
					if(current.index.Length() > 2){
						buds += current.branch0;
						buds += current.branch1;
					}
				}
				branches = buds;
				depth++;
			}
			return greatestTerm;
		}

	};
}

#endif
#ifndef BITSEQUENCE_CPP
#define BITSEQUENCE_CPP

#include "integer.h"
#include "stdlib.h"		//For malloc.
#include "ArrayList.h"
#include "SinglyLinkedList.h"

/*Size of long long ints, in bits.*/
#define lintsize (sizeof(unsigned long long int)*8)
/*Log size of long long ints, in bits.*/
#define lintlog	Integer::BinaryLog(lintsize)

namespace Juice{
	class BitSequence{
	private:
		/*A pointer to the data to be referenced.*/
		unsigned long long int * data;
		/*The length of the segment, in bits.*/
		unsigned long long int len;

	public:

		/*Default constructor.  Exists solely for allocation within arrays or some goofy stuff like that.*/
		BitSequence(){
			data = (unsigned long long int *)malloc(0);
			len = 0;
		}

		BitSequence(unsigned long long int segLength){  //tested
			data = (unsigned long long int *)malloc(length64(segLength)*8);
			len = segLength;

			if(pos(len))	//Attempting this when this condition is not met will reach into bad memory and cause a crash.
				*adr(len)=Integer::ClearTopIncl(*adr(len-1), pos(len)); //Clears the rightmost unused bits.  Stray data can screw with the shiftDown() routine.
		}

		BitSequence(void * byteAddress, unsigned long long int segLength){
			data = (unsigned long long int *)malloc(length64(segLength)*8);
			len = segLength;

			unsigned char * working = (unsigned char *)data;

			unsigned char * source = (unsigned char *)byteAddress;
			unsigned long long int len8 = length8();
			for(unsigned long long int i = 0ULL; i < len8; ++i)
				working[i] = source[i];			

			if(pos(len))   //Attempting this when this condition is not met will reach into bad memory and cause a crash.
				*adr(len) = Integer::ClearTopIncl(*adr(len-1), pos(len)); //Make sure the end-bits stay clear, or they may interfere with shiftDown.
		}

		BitSequence(void * byteAddress, unsigned char bitAddress, unsigned long long int segLength){	//tested
			data = (unsigned long long int *)malloc(length64(segLength)*8);
			len = segLength;

			if(!segLength)	return;	//Zero length will die at end-behavior

			//Fill the data.
			unsigned char * working = (unsigned char *)data;
			unsigned long long int len8 = length8(segLength);
			unsigned char * source = (unsigned char *)byteAddress;
			for(unsigned long long int i = 0ULL; i < len8-1; ++i)
				working[i] = (source[i] >> bitAddress) | (source[i+1] << (8-bitAddress));

			//End behavior is tigher so you don't reach into someone else's memory.
			if(length8(bitAddress+segLength)<len8)  //If you perform without this condition, you'll end up clearing out the last bits.
				working[len8-1] = source[len8-1]>>bitAddress;
			else                                    //The length of the source may exceed the length of the working.
				working[len8-1] = (source[len8-1]>>bitAddress) | (source[len8]<<(8-bitAddress));

			if(pos(len))   //Attempting this when this condition is not met will reach into bad memory and cause a crash.
				*adr(len) = Integer::ClearTopIncl(*adr(len-1), pos(len)); //Make sure the end-bits stay clear, or they may interfere with shiftDown.
		}
	
		/*The copy constructor allows for deep copies of this object.  When this object is passed through a function or set equal to another variable, the data it points to will also be copied.*/
		BitSequence(BitSequence& source){	//Untested
			len = source.Length();
			data = (unsigned long long int *)malloc(length64()*8);

			for(unsigned long long int i = 0ULL; i < length64(); ++i)
				data[i] = source.data[i];
		}
	
		/*The assignment operator works similarly to the copy constructor.*/
		BitSequence& operator=(BitSequence& source){	//Tested a little (in application, no benches)
			free(data);					//Clear old
			len = source.len;			//Reset length
			data = (unsigned long long int *)malloc(length64()*8);		//Allocate new memory
			unsigned long long int len64 = length64();					//Opvar
			for(unsigned long long int i = 0ULL; i < len64; ++i)		//Copy new data
				data[i] = source.data[i];
			return *this;												//Return reference to this
		}

		~BitSequence(){ //tested by extension of Constructor. (If this doesn't work, it would obviously crash)
			free(data);
		}

		void Length(unsigned long long int newLength){	//no testing needed
			len = newLength;

			realloc(data, length64()*8);

			if(pos(len))	//Attempting this when this condition is not met will reach into bad memory and cause a crash.
				*adr(len)=Integer::ClearTopIncl(*adr(len-1), pos(len)); //Clears the rightmost unused bits.  Stray data can screw with the shiftDown() routine.
		}
		unsigned long long int Length(){	            //no testing needed
			return len;
		}

		void Clear(unsigned long long int index){	//tested
			ListBoundingException::Validate(len, index);
			*adr(index) &= ~(1ULL<<pos(index));
		}

		void Clear(unsigned long long int index, unsigned long long int segLength){	//tested
			ListBoundingException::Validate(len, index + (segLength?segLength-1:0));
			for(unsigned long long int i = index; i < segLength+index; ++i)
				Clear(i);
		}

		void Set(unsigned long long int index){	    //tested
			ListBoundingException::Validate(len, index);
			*adr(index) |= 1ULL<<pos(index);
		}

		void Set(unsigned long long int index, unsigned long long int segLength){	//tested
			ListBoundingException::Validate(len, index + (segLength?segLength-1:0));
			for(unsigned long long int i = index; i < segLength+index; ++i)
				Set(i);
		}

		bool Read(unsigned long long int index){	    //tested
			ListBoundingException::Validate(len, index);
			return	Integer::Read(*adr(index), pos(index));
		}

		BitSequence Read(unsigned long long int index, unsigned long long int segLength){	//A temporary read-multiple.  Tested.
			ListBoundingException::Validate(len, index + (segLength?segLength-1:0));
			BitSequence returnVal(segLength);
			for(unsigned long long int i = 0ULL; i < segLength; ++i)
				Read(i+index) ? returnVal.Set(i) : returnVal.Clear(i);
			return returnVal;
		}

		//Temporary replacement of Write
		void Write(unsigned long long int index, BitSequence& source){
			for(unsigned long long int i = 0ULL; i < source.len; ++i)
				source.Read(i) ? Set(index+i) : Clear(index+i);
		}

		void ShiftUp(unsigned long long int offset){	//HUZZAH
			shiftLintsUp(offset/lintsize);
			shiftBitsUp(offset%lintsize);
		}
		void ShiftDown(unsigned long long int offset){	//TESTED
			shiftLintsDown(offset/lintsize);
			shiftBitsDown(offset%lintsize);
		}

		bool operator==(BitSequence& compare){ //untested
			if(compare.len!=len)
				return false;

			unsigned long long int len64 = length64();
			
			for(unsigned long long int i = 0ULL; i < len64; ++i){
				if(compare.data[i]!=data[i])
					return false;
			}

			return true;
		}
		bool operator!=(BitSequence& compare){	//untested
			if(compare.Length()!=Length())
				return true;

			for(unsigned long long int i = 0; i < length64(len); ++i){
				if(compare.data[i]!=data[i]){
					return true;
				}
			}
			return false;
		}

		static BitSequence Merge(ArrayList<BitSequence>& source){	//tested
			unsigned long long int totalLength = 0ULL;
			for(unsigned long long int i = 0ULL; i < source.Length(); ++i)
				totalLength += source[i].len;

			BitSequence result(totalLength);

			unsigned long long int currentPosition = 0ULL;
			for(unsigned long long int i = 0ULL; i < source.Length(); ++i){
				result.Write(currentPosition, source[i]);
				currentPosition += source[i].len;
			}
			return result;
		}

		ArrayList<BitSequence> Split(ArrayList<unsigned long long int> indicies){	//Should be a sorted list.  Splits before index.  ASSUME ORDERED INDICIES.	TESTED!!!
			ArrayList<BitSequence> returnVal(indicies.Length()+1);
			unsigned long long int currentPos = 0ULL;
			unsigned long long int segLength;
			for(unsigned long long int i = 0ULL; i < indicies.Length(); ++i){
				segLength = indicies[i] - currentPos;
				returnVal[i] = Read(currentPos, segLength);
				currentPos += segLength;
			}
			//Last one.
			returnVal[indicies.Length()] = Read(indicies[indicies.Length()-1], len - indicies[indicies.Length()-1]);

			return returnVal;
		}

		ArrayList<unsigned long long int> Search(BitSequence searchTerm, BitSequence replacement){			//Untested
			SinglyLinkedList<unsigned long long int> matches;
			for(unsigned long long int i = 0ULL; i < len - replacement.len; ++i){
				for(unsigned long long int j = 0; j < replacement.len; ++j){
					if(Read(i)!=replacement.Read(j))
						goto BreakToOuter;
				}
				matches.Prepend(i);
				BreakToOuter:;	//Label needs a semicolon apparently?
			}
			return (SinglyLinkedList<unsigned long long int>) matches;
		}

		void Replace(ArrayList<unsigned long long int> indicies, unsigned long long int cutLength, BitSequence replacement){	//We assume no terms overlap.  (Tested in CIDER)
			ArrayList<unsigned long long int> splitPoints(indicies.Length() * 2);
			
			for(unsigned long long int i = 0ULL; i < indicies.Length(); ++i){
				splitPoints[i*2] = indicies[i];
				splitPoints[i*2+1] = indicies[i] + cutLength;
			}
			ArrayList<BitSequence> terms = Split(splitPoints);

			for(unsigned long long int i = 1ULL; i < terms.Length(); i+=2)
				terms[i] = replacement;
			
			(*this) = Merge(terms);
		}

		void Remove(ArrayList<unsigned long long int> indicies, unsigned long long int segLength){
			ArrayList<unsigned long long int> splitPoints(indicies.Length() * 2);
			
			for(unsigned long long int i = 0ULL; i < indicies.Length(); ++i){
				splitPoints[i*2] = indicies[i];
				splitPoints[i*2+1] = indicies[i] + segLength;
			}
			ArrayList<BitSequence> terms = Split(splitPoints);
			ArrayList<BitSequence> newTerms(splitPoints.Length() / 2 + 1);	// +1 is because you always have at least one term.
			for(unsigned long long int i = 0ULL; i < newTerms.Length(); ++i)
				newTerms[i] = terms[i*2];
			
			(*this) = Merge(newTerms);
		}

		/*The index provided is where the object data begins.*/
		template<class T>
		T ToObject(unsigned long long int index = 0ULL){
			unsigned long long int objSize = (sizeof(T)*8 > len) ? len : sizeof(T)*8; 
			return *(reinterpret_cast<T*>(Read(index, objSize).data));
		}

		/*This thing doesn't check to make sure your object size is divisible, so be careful.  It'll leave the last value probably.*/
		template<class T>
		T * ToArray(){
			unsigned long long int arrayLength = len / sizeof(T) / 8;
			T * returnVal = new T[arrayLength];
			T * rawData = reinterpret_cast<T*>(data);
			for(unsigned long long int i = 0ULL; i < arrayLength; ++i)
				returnVal[i] = rawData[i];
			return returnVal;
		}

		char * ToCharArray(){		//Don't forget that the return needs to be garbage collected.
			char * result = new char[len+1];
			for(unsigned long long int i = 0ULL; i < len; ++i)
					result[i] = Read(i) ? '1' : '0';
			result[len]=0;
			return result;
		}

		/*Creates and returns a BitSequence based upon the data provided.  Takes the place of a template constructor.*/
		template<class T>								//untested, but copied from the other ones.
		static BitSequence Create(T sourceObj, unsigned long long int segLength){
			return BitSequence(&sourceObj, segLength);
		}

		private:
		   void shiftLintsDown(unsigned long long int offset){
				for(unsigned long long int i = 0; i < length64()-offset; ++i)
					data[i] = data[i+offset];
				for(unsigned long long int i = length64()-offset; i < length64(); ++i)
					data[i] = 0;
		   }
			void shiftBitsDown(unsigned char offset){
				for(unsigned long long int i = 0; i < length64()-1; ++i)
					data[i]=(data[i]>>offset)|(data[i+1]<<(lintsize-offset));
				data[length64()-1]>>=offset;
			}
			void shiftLintsUp(unsigned long long int offset){
				for(unsigned long long int i = 0; i < length64()-offset; ++i)
					data[i+offset] = data[i];
				for(unsigned long long int i = 0; i < offset; ++i)
					data[i] = 0;
			}
			void shiftBitsUp(unsigned char offset){
				for(unsigned long long int i = length64()-1; i != 0; --i)
					data[i] = (data[i-1]>>(lintsize - offset))|(data[i]<<offset);
				data[0]<<=offset;
			}

			static unsigned long long int length64(unsigned long long int lengthBits){
				return (lengthBits/lintsize)+(lengthBits%lintsize?1:0);
			}
			unsigned long long int length64(){
				return (len/lintsize)+((len%lintsize)?1:0);
			}
			unsigned long long int length8(unsigned long long int lengthBits){
				return lengthBits/8+(lengthBits%8?1:0);
			}
			unsigned long long int length8(){
				return len/8+(len%8?1:0);
			}
			/*Returns a pointer to the actual data of the integer that the index refers to.*/
			unsigned long long int * adr(unsigned long long int index){
				return data+index/lintsize;
			}
			/*Returns the bit-level position of the index, after the 64 bit plane (aka mod64).*/
			static unsigned char pos(unsigned long long int index){
				return index%lintsize;
			}
	};
	#undef lintlog
	#undef lintsize
}
#endif